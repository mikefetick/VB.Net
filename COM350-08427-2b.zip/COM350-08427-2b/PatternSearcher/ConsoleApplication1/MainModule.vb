﻿Imports PatternSearcher.SearchResults
Module MainModule
    Sub Main()
        Dim isCaseSensitive As Boolean = True
        Dim startingLocation As String = "..\..\"
        Dim fileType As String = "*.html"
        Dim pattern As String = "href"
        Dim aggrCount As Integer = 0
        Console.WriteLine(SummarizeSearchResults(startingLocation, fileType, pattern, isCaseSensitive, aggrCount))
        Console.WriteLine("Press any key to continue")
        Console.ReadKey()
    End Sub
End Module
