﻿Imports UnitTestPatternSearcher1.FoundResults
Imports UnitTestPatternSearcher1.PatternSearcher
Imports UnitTestPatternSearcher1.SearchResults

Module MainModule
    Public Sub Main()
        'Dim isCaseSensitive As Boolean
        Dim startingLocation As String = "..\..\"
        Dim fileType As String = ".html"
        Dim pattern As String = "href"
        Dim aggrCount As Integer = 0
        SummarizeSearchResults(startingLocation, fileType, pattern, aggrCount)
    End Sub

End Module
