﻿' <summary>
' COLEMAN UNIVERSITY, COM350 Visual Basic Programming
' Assignment: COM350-08427-2a
' This is a test class for project UnitTestPatternSearcher1
' and illustrated in ClassDiagram_PatternSearcher.cd
' These tests are developed for classes: PatternSearcher, SearchResults, and FoundResults
Imports System.Text
Imports Microsoft.VisualStudio.TestTools.UnitTesting
Imports System.IO

<TestClass()> Public Class UnitTest_PatternSearcher

    Private _FileType As String
    Private _IsCaseSensitive As Boolean
    Private _Pattern As String
    Private _StartingLocation As String
    Private filename As String
    Private aggrCount As Integer

#Region "Unit Tests - PatternSearcher Class"
    <TestInitialize()> _
    Public Sub Initialize()
        _FileType = ".html"
        _IsCaseSensitive = True
        _Pattern = "href"
        _StartingLocation = "..\..\"
        'Test purposes:
        'filename = "index.html"
        'filename = "unit-test.html"
        filename = "*.html"
        aggrCount = 0
    End Sub

    <TestMethod()> _
    Public Sub Validate_Starting_Location()
        'Dim isValidDirectory As Boolean = Directory.Exists(_StartingLocation)
        'Testing function call to ValidateStartingLocation(_StartingLocation)
        Dim isValidDirectory As Boolean = ValidateStartingLocation(_StartingLocation)
        If isValidDirectory Then
            Dim fullPath As String = New DirectoryInfo(_StartingLocation).FullName.ToString()
            Console.WriteLine("The path: '" & _StartingLocation & "' correctly identifies the full directory:")
            Console.WriteLine(fullPath)
        End If
        Assert.IsTrue(isValidDirectory, "The directory '" & _StartingLocation & "' should exist.")
    End Sub

    <TestMethod()> _
    Public Sub Extract_Filename_Extension_From_String()
        Dim extractedExtension As String = ""
        Dim dotIndex As Integer

        If filename <> Nothing And filename.Contains(".") Then
            dotIndex = filename.LastIndexOf(".")
            extractedExtension = filename.Substring(dotIndex, filename.Length - dotIndex)
            Console.WriteLine("The filename '" & filename & "' has the extension '" & extractedExtension & "'")
            'Testing function call to ValidateFileType(extractedExtension)
            If ValidateFileType(extractedExtension) Then
                Console.WriteLine("The extension '" & extractedExtension & "' is a valid file type.")
            Else
                Console.WriteLine("The extension '" & extractedExtension & "' is not a valid file type.")
            End If
        Else
            Console.WriteLine("The extension '" & extractedExtension & "' is not a valid file type.")
        End If
    End Sub

    <TestMethod()> _
    Public Sub Validate_FileType()
        Dim isValidExtension As Boolean = False
        Dim validExtensions As IEnumerable(Of String) = {".*", ".txt", ".html", ".xml"}

        isValidExtension = validExtensions.Any(Function(x) x = _FileType)
        'Assert.IsFalse(isValidExtension, "The file type '" & _FileType & "' is a valid file extension")
        Assert.IsTrue(isValidExtension, "The file type '" & _FileType & "' is not a valid file extension")
    End Sub

    <TestMethod()> _
    Public Sub Validate_File_Exists()
        Dim isFileFound As Boolean = False
        Dim di As New IO.DirectoryInfo(_StartingLocation)
        Dim aryFi As IO.FileInfo() = di.GetFiles(filename)
        Dim fi As IO.FileInfo
        For Each fi In aryFi
            isFileFound = True
        Next
        'Assert.IsFalse(isFileFound, "The file(s) identified by '" & filename & "' were found.")
        Assert.IsTrue(isFileFound, "The file(s) identified by '" & filename & "' were not found.")
    End Sub

    <TestMethod()> _
    Public Sub ValidateFileExists_Function_Call()
        Dim isFileFound As Boolean = False
        isFileFound = ValidateFileExists(filename)
        'Assert.IsFalse(isFileFound, "The file(s) identified by '" & filename & "' were found.")
        Assert.IsTrue(isFileFound, "The file(s) identified by '" & filename & "' were not found.")
    End Sub

    <TestMethod()> _
    Public Sub Validate_Pattern()
        Dim isValidPattern As Boolean = False
        Dim patternLength As Integer = _Pattern.Length
        'Assert.IsTrue(patternLength > 0, "The patterm '" & _Pattern & "' should not be empty.")
        Assert.IsTrue(ValidatePattern(_Pattern), "The pattern '" & _Pattern & "' should not be empty.")
    End Sub

#End Region

#Region "Unit Tests - FoundResults Class"
    'Validate test results by reviewing the output
    <TestMethod()> _
    Public Sub Find_Each_File()
        'Public Sub Validate_File_Exists(ByVal directory As String, ByVal filename As String)
        Dim di As New IO.DirectoryInfo(_StartingLocation)
        Dim aryFi As IO.FileInfo() = di.GetFiles(filename)
        Dim fi As IO.FileInfo
        Dim Matches As New List(Of FoundResults)

        'Change test results by changing the filename (file type will be checked)
        'Initialize filename = "index.html outputs foundresults line numbers: {8,28,29,30,44,59}
        'Initialize filename = "unit-test.html outputs foundresults line numbers: {8,28,29,30,54,55}
        'Initialize filename = "*.html outputs foundresults line numbers: {8,28,29,30,44,59,8,28,29,30,54,55}
        If _Pattern <> "" Then
            For Each fi In aryFi
                'For each file, call function to read and build list of foundresults
                Matches = ReadEachLine(_StartingLocation, fi.Name.ToString, _Pattern, aggrCount)
                For Each result As FoundResults In Matches
                    Console.WriteLine(result.GetDisplayText(vbTab))
                Next
            Next
        Else
            Console.WriteLine("A pattern must be provided to execute the search.")
        End If
    End Sub

    <TestMethod()> _
    Public Sub Read_Each_Line()
        Dim Matches As New List(Of FoundResults)
        'Already declared class instance variables:
        'Dim _Pattern As String = ""
        Dim filename As String = "index.html"
        Dim textIn As New StreamReader(
            New FileStream(_StartingLocation & filename, FileMode.OpenOrCreate, FileAccess.Read))
        Dim count As Integer = 0
        Dim rowNumber As Integer = 1

        Do While textIn.Peek <> -1
            Dim row As String = textIn.ReadLine
            If row.Contains(_Pattern) Then
                Dim aMatch As New FoundResults
                With aMatch
                    .BaseFileName = filename
                    .LineNumber = rowNumber
                    .InputLine = row
                End With
                Matches.Add(aMatch)
                count += 1
            End If
            rowNumber += 1
        Loop
        textIn.Close()

        For Each result As FoundResults In Matches
            Console.WriteLine(result.GetDisplayText(vbTab))
        Next

    End Sub

#End Region

#Region "Unit Tests - SearchResults Class"
    'Validate test results by reviewing the output
    <TestMethod()> _
    Public Sub Summarize_Search_Results()
        'Measure elapsed time of search between start and stop times
        Static start_time As DateTime
        Static stop_time As DateTime
        Dim elapsed_time As TimeSpan

        start_time = Now
        'Call function to increment the aggrCount (param ByRef)
        FindEachFile(_StartingLocation, filename, _Pattern, aggrCount)
        stop_time = Now
        elapsed_time = stop_time.Subtract(start_time)

        Console.WriteLine("Search results: Found " & aggrCount & " matches in " _
                          & elapsed_time.TotalSeconds.ToString("0.000000") & " seconds")
        Console.WriteLine()
        'Call sub to output the FoundResults
        Find_Each_File()
    End Sub

    'Validate test results by reviewing the output
    <TestMethod()> _
    Public Sub SummarizeSearchResults_Function_Call()
        Console.WriteLine(SummarizeSearchResults())
        Console.WriteLine()
        'Call sub to output the FoundResults
        Find_Each_File()
    End Sub

#End Region

#Region "PatternSearcher Functions"
    Private Function ValidateStartingLocation(path As String) As Boolean
        Return Directory.Exists(path)
    End Function

    Public Function ExtractFilenameExtensionFromString(filename As String) As String
        Dim extractedExtension As String = ""
        Dim dotIndex As Integer = 0
        If filename <> Nothing And filename.Contains(".") Then
            dotIndex = filename.LastIndexOf(".")
            extractedExtension = filename.Substring(dotIndex, filename.Length - dotIndex)
            If ValidateFileType(extractedExtension) Then
                Return extractedExtension
            End If
        End If
        Return Nothing
    End Function

    Public Function ValidateFileType(filetype As String) As Boolean
        Dim isValidExtension As Boolean = False
        Dim validExtensions As IEnumerable(Of String) = {".*", ".txt", ".html", ".xml"}

        isValidExtension = validExtensions.Any(Function(x) x = filetype)
        Return isValidExtension
    End Function

    Public Function ValidateFileExists(filename As String) As Boolean
        'Public Sub Validate_File_Exists(ByVal directory As String, ByVal filename As String)
        Dim isFileFound As Boolean = False
        Dim di As New IO.DirectoryInfo(_StartingLocation)
        Dim aryFi As IO.FileInfo() = di.GetFiles(filename)
        Dim fi As IO.FileInfo

        For Each fi In aryFi
            isFileFound = True
        Next

        Return isFileFound
    End Function

    Public Function ValidatePattern(pattern As String) As Boolean
        If pattern.Length > 0 Then
            Return True
        End If
        Return False
    End Function

#End Region

#Region "FoundResults Functions"
    'Appended aggrCount to param list ByRef
    Public Shared Function FindEachFile(_StartingLocation As String, _
                                        filename As String, _
                                        _Pattern As String, _
                                        ByRef aggrCount As Integer) As Boolean
        Dim isFileFound As Boolean = False
        Dim di As New IO.DirectoryInfo(_StartingLocation)
        Dim aryFi As IO.FileInfo() = di.GetFiles(filename)
        Dim fi As IO.FileInfo

        If _Pattern <> "" Then
            For Each fi In aryFi
                'Appended aggrCount to param list ByRef
                ReadEachLine(_StartingLocation, fi.Name.ToString, _Pattern, aggrCount)
                isFileFound = True
            Next
        Else
            Console.WriteLine("A pattern must be provided to execute the search.")
        End If

        Return isFileFound
    End Function

    'Appended aggrCount to param list ByRef
    Public Shared Function ReadEachLine(_StartingLocation As String, _
                                        filename As String, _
                                        _Pattern As String, _
                                        ByRef aggrCount As Integer) As List(Of FoundResults)
        Dim Matches As New List(Of FoundResults)
        Dim textIn As New StreamReader(
            New FileStream(_StartingLocation & filename, FileMode.OpenOrCreate, FileAccess.Read))
        Dim count As Integer = 0
        Dim rowNumber As Integer = 1

        Do While textIn.Peek <> -1
            Dim row As String = textIn.ReadLine
            If row.Contains(_Pattern) Then
                Dim aMatch As New FoundResults
                With aMatch
                    .BaseFileName = filename
                    .LineNumber = rowNumber
                    .InputLine = row
                End With
                Matches.Add(aMatch)
                count += 1
                aggrCount += 1
            End If
            rowNumber += 1
        Loop
        textIn.Close()
        Return Matches
    End Function

#End Region

#Region "SearchResults Functions"

    Public Function SummarizeSearchResults() As String
        'Measure elapsed time of search between start and stop times
        Static start_time As DateTime
        Static stop_time As DateTime
        Dim elapsed_time As TimeSpan

        start_time = Now
        'Call function to increment the aggrCount (param ByRef)
        FindEachFile(_StartingLocation, filename, _Pattern, aggrCount)
        stop_time = Now
        elapsed_time = stop_time.Subtract(start_time)

        Return "Search results: Found " & aggrCount & " matches in " _
                          & elapsed_time.TotalSeconds.ToString("0.000000") & " seconds"
    End Function

#End Region

End Class
