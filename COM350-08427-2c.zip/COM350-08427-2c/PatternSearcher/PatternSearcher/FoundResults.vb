﻿' This is a class in project UnitTestPatternSearcher1
Imports System.IO
Imports System.Windows.Forms

Public Class FoundResults
    Public Sub New()
        'Empty constructor
    End Sub
    Public Sub New(baseFileName As String, inputLine As String, lineNumber As Integer)
        Me.BaseFileName = baseFileName
        Me.InputLine = inputLine
        Me.LineNumber = lineNumber
    End Sub

    Public Property BaseFileName As String

    Public Property InputLine As String

    Public Property LineNumber As Integer

    Public Function GetDisplayText(sep As String) As String
        Dim text As String = BaseFileName.PadRight(20) & sep &
            LineNumber.ToString.PadRight(25) & sep &
            InputLine
        Return text
    End Function

    Friend Shared Function FindMatchesForGUI(_StartingLocation As String, filename As String, _Pattern As String, _
                                        ByRef aggrCount As Integer) As Boolean
        Dim isFileFound As Boolean = False
        Dim di As New IO.DirectoryInfo(_StartingLocation)
        Dim diName = di.FullName
        Dim aryFi As IO.FileInfo() = di.GetFiles(filename)
        Dim fi As IO.FileInfo
        Dim Matches As New List(Of FoundResults)
        Dim searchResults As String = ""
        searchResults = String.Format("Search for text '{0}' within files '{1}' in directory:" _
                                      + vbNewLine + "'{2}' resulted:" _
                                      + vbNewLine, _Pattern, filename, diName)
        If _Pattern <> "" Then
            For Each fi In aryFi
                isFileFound = True
                'For each file, call function to read and build list of foundresults with aggrCount ByRef
                Matches = ReadEachLine(_StartingLocation, fi.Name.ToString, _Pattern, aggrCount)
                For Each result As FoundResults In Matches
                    searchResults += (result.GetDisplayText(vbTab)) + vbNewLine
                Next
            Next
            frmPatternSearcher.tbxFoundResults.Text += searchResults
        Else
            MessageBox.Show("A pattern must be provided to execute the search.")
        End If
        Return isFileFound

    End Function

    Friend Shared Function FindMatchesForConsole(_StartingLocation As String, filename As String, _Pattern As String, _
                                        ByRef aggrCount As Integer) As Boolean
        Dim isFileFound As Boolean = False
        Dim di As New IO.DirectoryInfo(_StartingLocation)
        Dim diName = di.FullName
        Dim aryFi As IO.FileInfo() = di.GetFiles(filename)
        Dim fi As IO.FileInfo
        Dim Matches As New List(Of FoundResults)
        Console.WriteLine("Search for text '{0}' within files '{1}' in directory '{2}' resulted:", _Pattern, filename, diName)
        If _Pattern <> "" Then
            For Each fi In aryFi
                isFileFound = True
                'For each file, call function to read and build list of foundresults with aggrCount ByRef
                Matches = ReadEachLine(_StartingLocation, fi.Name.ToString, _Pattern, aggrCount)
                For Each result As FoundResults In Matches
                    Console.WriteLine(result.GetDisplayText(vbTab))
                Next
            Next
        Else
            Console.WriteLine("A pattern must be provided to execute the search.")
        End If

        Return isFileFound

    End Function

    Public Shared Function ReadEachLine(_StartingLocation As String, _
                                        filename As String, _
                                        _Pattern As String, _
                                        ByRef aggrCount As Integer) As List(Of FoundResults)
        Dim Matches As New List(Of FoundResults)
        Dim textIn As New StreamReader(
            New FileStream(_StartingLocation & filename, FileMode.OpenOrCreate, FileAccess.Read))
        Dim count As Integer = 0
        Dim rowNumber As Integer = 1

        Do While textIn.Peek <> -1
            Dim row As String = textIn.ReadLine
            'Using the Contains method to find a match to the pattern
            'this method does the work shown in class to split the line.
            If row.Contains(_Pattern) Then
                Dim aMatch As New FoundResults
                With aMatch
                    .BaseFileName = filename
                    .LineNumber = rowNumber
                    .InputLine = row
                End With
                Matches.Add(aMatch)
                count += 1
                aggrCount += 1
            End If
            rowNumber += 1
        Loop
        textIn.Close()
        Return Matches

    End Function

End Class
