﻿' This is a class in project UnitTestPatternSearcher1
Imports System.IO
Public Class SearchResults
    Public Sub New()
        'Empty constructor
    End Sub
    Public Sub New(matches As List(Of FoundResults), results As Integer, time As Integer)
        Me.Matches = matches
        Me.Results = results
        Me.Time = time
    End Sub

    Public Property Matches As List(Of FoundResults)

    Public Property Results As Integer

    Public Property Time As Integer

    Public Shared Function SummarizeSearchResults(_StartingLocation As String, _
                                           filename As String, _
                                           _Pattern As String, _
                                           isCaseSensitive As Boolean, _
                                           ByRef aggrCount As Integer) As String
        'Measure elapsed time of search between start and stop times
        Static start_time As DateTime
        Static stop_time As DateTime
        Dim elapsed_time As TimeSpan

        start_time = Now
        If Not isCaseSensitive Then
            _Pattern = _Pattern.ToLower()
        End If
        'Call function to increment the aggrCount (param ByRef)
        'FoundResults.FindEachFile(_StartingLocation, filename, _Pattern, aggrCount)
        stop_time = Now
        elapsed_time = stop_time.Subtract(start_time)

        Return "Search results: Found " & aggrCount & " matches in " _
                          & elapsed_time.TotalSeconds.ToString("0.000000") & " seconds"
    End Function

End Class
