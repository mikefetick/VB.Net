﻿Imports PatternSearcher.SearchResults
Imports PatternSearcher.frmPatternSearcher
Imports PatternSearcher.FoundResults
Module MainModule
    Sub Main()
        frmPatternSearcher.ShowDialog()
    End Sub
End Module
