﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPatternSearcher
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.tbxStartingLocation = New System.Windows.Forms.TextBox()
        Me.lblStartingLocation = New System.Windows.Forms.Label()
        Me.btnLoad = New System.Windows.Forms.Button()
        Me.btnStart = New System.Windows.Forms.Button()
        Me.cbxFileTypes = New System.Windows.Forms.ComboBox()
        Me.PatternSearcherBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.lblPattern = New System.Windows.Forms.Label()
        Me.tbxPattern = New System.Windows.Forms.TextBox()
        Me.lblFileTypes = New System.Windows.Forms.Label()
        Me.lblFoundResults = New System.Windows.Forms.Label()
        Me.tbxFoundResults = New System.Windows.Forms.TextBox()
        Me.chkCaseSensitive = New System.Windows.Forms.CheckBox()
        CType(Me.PatternSearcherBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'tbxStartingLocation
        '
        Me.tbxStartingLocation.Location = New System.Drawing.Point(45, 60)
        Me.tbxStartingLocation.Name = "tbxStartingLocation"
        Me.tbxStartingLocation.Size = New System.Drawing.Size(680, 31)
        Me.tbxStartingLocation.TabIndex = 0
        '
        'lblStartingLocation
        '
        Me.lblStartingLocation.AutoSize = True
        Me.lblStartingLocation.Location = New System.Drawing.Point(40, 20)
        Me.lblStartingLocation.Name = "lblStartingLocation"
        Me.lblStartingLocation.Size = New System.Drawing.Size(174, 25)
        Me.lblStartingLocation.TabIndex = 1
        Me.lblStartingLocation.Text = "Starting Location"
        '
        'btnLoad
        '
        Me.btnLoad.Location = New System.Drawing.Point(740, 57)
        Me.btnLoad.Name = "btnLoad"
        Me.btnLoad.Size = New System.Drawing.Size(100, 40)
        Me.btnLoad.TabIndex = 2
        Me.btnLoad.Text = "Load"
        Me.btnLoad.UseVisualStyleBackColor = True
        '
        'btnStart
        '
        Me.btnStart.Enabled = False
        Me.btnStart.Location = New System.Drawing.Point(740, 137)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(100, 40)
        Me.btnStart.TabIndex = 3
        Me.btnStart.Text = "Start"
        Me.btnStart.UseVisualStyleBackColor = True
        '
        'cbxFileTypes
        '
        Me.cbxFileTypes.FormattingEnabled = True
        Me.cbxFileTypes.Items.AddRange(New Object() {"*.*", "*.txt", "*.html", "*.xml"})
        Me.cbxFileTypes.Location = New System.Drawing.Point(45, 140)
        Me.cbxFileTypes.Name = "cbxFileTypes"
        Me.cbxFileTypes.Size = New System.Drawing.Size(125, 33)
        Me.cbxFileTypes.TabIndex = 4
        '
        'lblPattern
        '
        Me.lblPattern.AutoSize = True
        Me.lblPattern.Location = New System.Drawing.Point(188, 105)
        Me.lblPattern.Name = "lblPattern"
        Me.lblPattern.Size = New System.Drawing.Size(81, 25)
        Me.lblPattern.TabIndex = 6
        Me.lblPattern.Text = "Pattern"
        '
        'tbxPattern
        '
        Me.tbxPattern.Location = New System.Drawing.Point(193, 140)
        Me.tbxPattern.Name = "tbxPattern"
        Me.tbxPattern.Size = New System.Drawing.Size(140, 31)
        Me.tbxPattern.TabIndex = 5
        '
        'lblFileTypes
        '
        Me.lblFileTypes.AutoSize = True
        Me.lblFileTypes.Location = New System.Drawing.Point(40, 105)
        Me.lblFileTypes.Name = "lblFileTypes"
        Me.lblFileTypes.Size = New System.Drawing.Size(58, 25)
        Me.lblFileTypes.TabIndex = 7
        Me.lblFileTypes.Text = "Files"
        '
        'lblFoundResults
        '
        Me.lblFoundResults.AutoSize = True
        Me.lblFoundResults.Location = New System.Drawing.Point(40, 469)
        Me.lblFoundResults.Name = "lblFoundResults"
        Me.lblFoundResults.Size = New System.Drawing.Size(157, 25)
        Me.lblFoundResults.TabIndex = 8
        Me.lblFoundResults.Text = "Found Results:"
        '
        'tbxFoundResults
        '
        Me.tbxFoundResults.Location = New System.Drawing.Point(45, 213)
        Me.tbxFoundResults.Multiline = True
        Me.tbxFoundResults.Name = "tbxFoundResults"
        Me.tbxFoundResults.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.tbxFoundResults.Size = New System.Drawing.Size(795, 230)
        Me.tbxFoundResults.TabIndex = 9
        Me.tbxFoundResults.WordWrap = False
        '
        'chkCaseSensitive
        '
        Me.chkCaseSensitive.AutoSize = True
        Me.chkCaseSensitive.Checked = True
        Me.chkCaseSensitive.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkCaseSensitive.Location = New System.Drawing.Point(376, 137)
        Me.chkCaseSensitive.Name = "chkCaseSensitive"
        Me.chkCaseSensitive.Size = New System.Drawing.Size(188, 29)
        Me.chkCaseSensitive.TabIndex = 10
        Me.chkCaseSensitive.Text = "Case Sensitive"
        Me.chkCaseSensitive.UseVisualStyleBackColor = True
        '
        'frmPatternSearcher
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(874, 529)
        Me.Controls.Add(Me.chkCaseSensitive)
        Me.Controls.Add(Me.tbxFoundResults)
        Me.Controls.Add(Me.lblFoundResults)
        Me.Controls.Add(Me.lblFileTypes)
        Me.Controls.Add(Me.lblPattern)
        Me.Controls.Add(Me.tbxPattern)
        Me.Controls.Add(Me.cbxFileTypes)
        Me.Controls.Add(Me.btnStart)
        Me.Controls.Add(Me.btnLoad)
        Me.Controls.Add(Me.lblStartingLocation)
        Me.Controls.Add(Me.tbxStartingLocation)
        Me.Name = "frmPatternSearcher"
        Me.Text = "Form - Search Pattern"
        CType(Me.PatternSearcherBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents tbxStartingLocation As System.Windows.Forms.TextBox
    Friend WithEvents lblStartingLocation As System.Windows.Forms.Label
    Friend WithEvents btnLoad As System.Windows.Forms.Button
    Friend WithEvents btnStart As System.Windows.Forms.Button
    Friend WithEvents cbxFileTypes As System.Windows.Forms.ComboBox
    Friend WithEvents lblPattern As System.Windows.Forms.Label
    Friend WithEvents tbxPattern As System.Windows.Forms.TextBox
    Friend WithEvents lblFileTypes As System.Windows.Forms.Label
    Friend WithEvents lblFoundResults As System.Windows.Forms.Label
    Friend WithEvents tbxFoundResults As System.Windows.Forms.TextBox
    Friend WithEvents PatternSearcherBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents chkCaseSensitive As System.Windows.Forms.CheckBox
End Class
