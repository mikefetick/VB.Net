﻿Imports System.Windows.Forms
Imports PatternSearcher.FoundResults
Imports PatternSearcher.SearchResults
Public Class frmPatternSearcher
    Dim folderDlg As New FolderBrowserDialog
    Private Sub enableBtnStart()
        btnStart.Enabled = tbxStartingLocation.Text.Trim().Length > 0 _
            And cbxFileTypes.Text.Trim().Length > 0 _
            And tbxPattern.Text.Trim().Length > 0
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim startingLocation As String = "..\..\"
        Dim fileType As String = "*.html"
        Dim pattern As String = "href"
        Dim validExtensions As IEnumerable(Of String) = {".*", ".txt", ".html", ".xml"}

        tbxStartingLocation.Text = startingLocation
        '.cbxFileTypes = validExtensions
        cbxFileTypes.Text = fileType
        tbxPattern.Text = pattern
    End Sub

    Private Sub cbxFileTypes_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbxFileTypes.SelectedIndexChanged
        enableBtnStart()
    End Sub

    Private Sub tbxStartingLocation_TextChanged(sender As Object, e As EventArgs) Handles tbxStartingLocation.TextChanged
        enableBtnStart()
    End Sub

    Private Sub tbxPattern_TextChanged(sender As Object, e As EventArgs) Handles tbxPattern.TextChanged
        enableBtnStart()
    End Sub

    Private Sub btnLoad_Click(sender As Object, e As EventArgs) Handles btnLoad.Click
        'For user to search for files, set root of folder dialog to users desktop
        folderDlg.RootFolder = Environment.SpecialFolder.DesktopDirectory
        folderDlg.ShowNewFolderButton = True
        If (folderDlg.ShowDialog() = DialogResult.OK) Then
            tbxStartingLocation.Text = folderDlg.SelectedPath
            Dim root As Environment.SpecialFolder = folderDlg.RootFolder
        End If
    End Sub

    Private Sub btnStart_Click(sender As Object, e As EventArgs) Handles btnStart.Click
        Dim isCaseSensitive As Boolean = True
        Dim aggrCount As Integer = 0
        Dim searchResults As String = ""
        Dim Matches As New List(Of FoundResults)
        'Measure elapsed time of search between start and stop times
        Static start_time As DateTime
        Static stop_time As DateTime
        Dim elapsed_time As TimeSpan = Nothing
        Dim pattern As String = ""

        start_time = Now
        If chkCaseSensitive.Checked Then
            pattern = tbxPattern.Text
        Else
            pattern = tbxPattern.Text.ToLower()
        End If
        'Reset the results everytime the start button is pushed.
        tbxFoundResults.Text = ""
        'Call function to increment the aggrCount (param ByRef)
        If FindMatchesForGUI(tbxStartingLocation.Text, _
                                 cbxFileTypes.Text, _
                                 pattern, _
                                 aggrCount) Then
        Else
            tbxFoundResults.Text = "The pattern was not found within the file(s) search."
        End If
        'For Each result As FoundResults In Matches
        'searchResults += (result.GetDisplayText(vbTab)) + vbNewLine
        'Next
        'tbxFoundResults.Text = searchResults
        stop_time = Now
        elapsed_time = stop_time.Subtract(start_time)

        'Summarized results
        lblFoundResults.Text = "Search results: Found " & aggrCount & " matches in " _
                         & elapsed_time.TotalSeconds.ToString("0.000000") & " seconds"

        Me.Show()

    End Sub
End Class