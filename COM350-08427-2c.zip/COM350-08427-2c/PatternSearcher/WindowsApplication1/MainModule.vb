﻿Imports PatternSearcher.SearchResults
Imports PatternSearcher.frmPatternSearcher
Imports PatternSearcher.FoundResults
Module MainModule
    Sub Main()
        frmPatternSearcher.ShowDialog()

        'Console.WriteLine(SummarizeSearchResults(startingLocation, fileType, pattern, isCaseSensitive, aggrCount))
        'Console.WriteLine("Press any key to continue")
        'Console.ReadKey()
    End Sub
End Module
