﻿Public Class FormStudentMasterDetail

    Private Sub FormStudentMasterDetail_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Size = New System.Drawing.Size(510, 450)
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvStudentRecords.CellContentClick

    End Sub

    Private Sub rbtnSQLserver_CheckedChanged(sender As Object, e As EventArgs) Handles rbtnSQLserver.CheckedChanged

    End Sub

    Private Sub rbtnMySQL_CheckedChanged(sender As Object, e As EventArgs) Handles rbtnMySQL.CheckedChanged

    End Sub
End Class
