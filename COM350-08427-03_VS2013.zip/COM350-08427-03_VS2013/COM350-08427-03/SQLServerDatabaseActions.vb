﻿Imports System.Data
Imports System.Data.SqlClient

Public Class SQLServerDatabaseActions
    Implements IDatabaseActions

    Private connectionString As String = ""
    Private rowsAffected As Integer
    Private databasePath As String = ""
    Private sqlMask As String = "INSERT INTO Languages (Language) VALUES " & _
                                 "('{0}')"

    Public Function AddNewRecord(language As String) As Integer _
        Implements IDatabaseActions.AddNewRecord

        Dim sqlQuery As String = String.Format(sqlMask, language)

        Using conn As New SqlConnection()
            conn.ConnectionString = connectionString
            conn.Open()

            Dim oleCmd As SqlCommand = New SqlCommand(sqlQuery, conn)
            rowsAffected = oleCmd.ExecuteNonQuery()

        End Using

        Return rowsAffected
    End Function

    Public Function UpdateNewRecord(ByVal languageID As Integer, ByVal language As String) As Integer _
        Implements IDatabaseActions.UpdateRecord
        Dim sqlQuery As String = "UPDATE Languages SET Language = @Language " & _
                                 "WHERE LanguageID = @LanguageID"

        Using conn As New SqlConnection()
            conn.ConnectionString = connectionString
            conn.Open()

            Dim oleCmd As SqlCommand = New SqlCommand(sqlQuery, conn)
            oleCmd.Parameters.Add("@LanguageID", SqlDbType.Int).Value = languageID
            oleCmd.Parameters.Add("@Language", SqlDbType.VarChar, 50).Value = language

            rowsAffected = oleCmd.ExecuteNonQuery()

        End Using

        Return rowsAffected
    End Function

    Public Function DeleteRecord(ByVal LanguageID As Integer) As Integer _
        Implements IDatabaseActions.DeleteRecord
        Dim sqlQuery As String = "DeleteLanguage"

        Using conn As New SqlConnection()
            conn.ConnectionString = connectionString
            conn.Open()

            Dim oleCmd As SqlCommand = New SqlCommand(sqlQuery, conn)
            oleCmd.CommandType = CommandType.StoredProcedure
            oleCmd.Parameters.Add("@LanguageID", SqlDbType.Int).Value = LanguageID

            rowsAffected = oleCmd.ExecuteNonQuery()

        End Using

        Return rowsAffected

    End Function
End Class
