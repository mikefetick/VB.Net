﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormStudentMasterDetail
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.tbxLanguage = New System.Windows.Forms.TextBox()
        Me.lblLanguage = New System.Windows.Forms.Label()
        Me.btnInsertLanguage = New System.Windows.Forms.Button()
        Me.dgvStudentRecords = New System.Windows.Forms.DataGridView()
        Me.lblStudentID = New System.Windows.Forms.Label()
        Me.tbxStudentID = New System.Windows.Forms.TextBox()
        Me.lblStudentGPA = New System.Windows.Forms.Label()
        Me.tbxStudentGPA = New System.Windows.Forms.TextBox()
        Me.lblStudentName = New System.Windows.Forms.Label()
        Me.tbxStudentName = New System.Windows.Forms.TextBox()
        Me.lblStudentMajor = New System.Windows.Forms.Label()
        Me.tbxStudentMajor = New System.Windows.Forms.TextBox()
        Me.lblEnrollmentDate = New System.Windows.Forms.Label()
        Me.lblGraduationDate = New System.Windows.Forms.Label()
        Me.btnInsertRecord = New System.Windows.Forms.Button()
        Me.btnUpdateRecord = New System.Windows.Forms.Button()
        Me.btnDeleteRecord = New System.Windows.Forms.Button()
        Me.btnClearFields = New System.Windows.Forms.Button()
        Me.cbxEnrollmentDate = New System.Windows.Forms.ComboBox()
        Me.cbxGraduationDate = New System.Windows.Forms.ComboBox()
        Me.rbtnSQLserver = New System.Windows.Forms.RadioButton()
        Me.rbtnMySQL = New System.Windows.Forms.RadioButton()
        Me.gbxInsertRecordSample = New System.Windows.Forms.GroupBox()
        CType(Me.dgvStudentRecords, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbxInsertRecordSample.SuspendLayout()
        Me.SuspendLayout()
        '
        'tbxLanguage
        '
        Me.tbxLanguage.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbxLanguage.Location = New System.Drawing.Point(159, 51)
        Me.tbxLanguage.Name = "tbxLanguage"
        Me.tbxLanguage.Size = New System.Drawing.Size(200, 35)
        Me.tbxLanguage.TabIndex = 0
        '
        'lblLanguage
        '
        Me.lblLanguage.AutoSize = True
        Me.lblLanguage.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLanguage.Location = New System.Drawing.Point(14, 54)
        Me.lblLanguage.Name = "lblLanguage"
        Me.lblLanguage.Size = New System.Drawing.Size(126, 29)
        Me.lblLanguage.TabIndex = 3
        Me.lblLanguage.Text = "Language:"
        '
        'btnInsertLanguage
        '
        Me.btnInsertLanguage.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnInsertLanguage.Location = New System.Drawing.Point(374, 50)
        Me.btnInsertLanguage.Name = "btnInsertLanguage"
        Me.btnInsertLanguage.Size = New System.Drawing.Size(200, 46)
        Me.btnInsertLanguage.TabIndex = 4
        Me.btnInsertLanguage.Text = "Insert Record"
        Me.btnInsertLanguage.UseVisualStyleBackColor = True
        '
        'dgvStudentRecords
        '
        Me.dgvStudentRecords.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvStudentRecords.Location = New System.Drawing.Point(40, 230)
        Me.dgvStudentRecords.Name = "dgvStudentRecords"
        Me.dgvStudentRecords.RowTemplate.Height = 33
        Me.dgvStudentRecords.Size = New System.Drawing.Size(900, 240)
        Me.dgvStudentRecords.TabIndex = 6
        '
        'lblStudentID
        '
        Me.lblStudentID.AutoSize = True
        Me.lblStudentID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStudentID.Location = New System.Drawing.Point(50, 490)
        Me.lblStudentID.Name = "lblStudentID"
        Me.lblStudentID.Size = New System.Drawing.Size(130, 29)
        Me.lblStudentID.TabIndex = 8
        Me.lblStudentID.Text = "Student ID:"
        '
        'tbxStudentID
        '
        Me.tbxStudentID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbxStudentID.Location = New System.Drawing.Point(225, 490)
        Me.tbxStudentID.Name = "tbxStudentID"
        Me.tbxStudentID.Size = New System.Drawing.Size(170, 35)
        Me.tbxStudentID.TabIndex = 7
        '
        'lblStudentGPA
        '
        Me.lblStudentGPA.AutoSize = True
        Me.lblStudentGPA.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStudentGPA.Location = New System.Drawing.Point(50, 535)
        Me.lblStudentGPA.Name = "lblStudentGPA"
        Me.lblStudentGPA.Size = New System.Drawing.Size(156, 29)
        Me.lblStudentGPA.TabIndex = 10
        Me.lblStudentGPA.Text = "Student GPA:"
        '
        'tbxStudentGPA
        '
        Me.tbxStudentGPA.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbxStudentGPA.Location = New System.Drawing.Point(225, 535)
        Me.tbxStudentGPA.Name = "tbxStudentGPA"
        Me.tbxStudentGPA.Size = New System.Drawing.Size(170, 35)
        Me.tbxStudentGPA.TabIndex = 9
        '
        'lblStudentName
        '
        Me.lblStudentName.AutoSize = True
        Me.lblStudentName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStudentName.Location = New System.Drawing.Point(50, 580)
        Me.lblStudentName.Name = "lblStudentName"
        Me.lblStudentName.Size = New System.Drawing.Size(84, 29)
        Me.lblStudentName.TabIndex = 12
        Me.lblStudentName.Text = "Name:"
        '
        'tbxStudentName
        '
        Me.tbxStudentName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbxStudentName.Location = New System.Drawing.Point(225, 580)
        Me.tbxStudentName.Name = "tbxStudentName"
        Me.tbxStudentName.Size = New System.Drawing.Size(350, 35)
        Me.tbxStudentName.TabIndex = 11
        '
        'lblStudentMajor
        '
        Me.lblStudentMajor.AutoSize = True
        Me.lblStudentMajor.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStudentMajor.Location = New System.Drawing.Point(50, 625)
        Me.lblStudentMajor.Name = "lblStudentMajor"
        Me.lblStudentMajor.Size = New System.Drawing.Size(168, 29)
        Me.lblStudentMajor.TabIndex = 14
        Me.lblStudentMajor.Text = "Student Major:"
        '
        'tbxStudentMajor
        '
        Me.tbxStudentMajor.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbxStudentMajor.Location = New System.Drawing.Point(225, 625)
        Me.tbxStudentMajor.Name = "tbxStudentMajor"
        Me.tbxStudentMajor.Size = New System.Drawing.Size(170, 35)
        Me.tbxStudentMajor.TabIndex = 13
        '
        'lblEnrollmentDate
        '
        Me.lblEnrollmentDate.AutoSize = True
        Me.lblEnrollmentDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEnrollmentDate.Location = New System.Drawing.Point(410, 490)
        Me.lblEnrollmentDate.Name = "lblEnrollmentDate"
        Me.lblEnrollmentDate.Size = New System.Drawing.Size(191, 29)
        Me.lblEnrollmentDate.TabIndex = 16
        Me.lblEnrollmentDate.Text = "Enrollment Date:"
        '
        'lblGraduationDate
        '
        Me.lblGraduationDate.AutoSize = True
        Me.lblGraduationDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGraduationDate.Location = New System.Drawing.Point(410, 535)
        Me.lblGraduationDate.Name = "lblGraduationDate"
        Me.lblGraduationDate.Size = New System.Drawing.Size(193, 29)
        Me.lblGraduationDate.TabIndex = 17
        Me.lblGraduationDate.Text = "Graduation Date:"
        '
        'btnInsertRecord
        '
        Me.btnInsertRecord.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnInsertRecord.Location = New System.Drawing.Point(75, 700)
        Me.btnInsertRecord.Name = "btnInsertRecord"
        Me.btnInsertRecord.Size = New System.Drawing.Size(190, 50)
        Me.btnInsertRecord.TabIndex = 18
        Me.btnInsertRecord.Text = "Insert Record"
        Me.btnInsertRecord.UseVisualStyleBackColor = True
        '
        'btnUpdateRecord
        '
        Me.btnUpdateRecord.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUpdateRecord.Location = New System.Drawing.Point(290, 700)
        Me.btnUpdateRecord.Name = "btnUpdateRecord"
        Me.btnUpdateRecord.Size = New System.Drawing.Size(190, 50)
        Me.btnUpdateRecord.TabIndex = 19
        Me.btnUpdateRecord.Text = "Update Record"
        Me.btnUpdateRecord.UseVisualStyleBackColor = True
        '
        'btnDeleteRecord
        '
        Me.btnDeleteRecord.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDeleteRecord.Location = New System.Drawing.Point(505, 700)
        Me.btnDeleteRecord.Name = "btnDeleteRecord"
        Me.btnDeleteRecord.Size = New System.Drawing.Size(190, 50)
        Me.btnDeleteRecord.TabIndex = 20
        Me.btnDeleteRecord.Text = "Delete Record"
        Me.btnDeleteRecord.UseVisualStyleBackColor = True
        '
        'btnClearFields
        '
        Me.btnClearFields.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClearFields.Location = New System.Drawing.Point(720, 700)
        Me.btnClearFields.Name = "btnClearFields"
        Me.btnClearFields.Size = New System.Drawing.Size(190, 50)
        Me.btnClearFields.TabIndex = 21
        Me.btnClearFields.Text = "Clear Fields"
        Me.btnClearFields.UseVisualStyleBackColor = True
        '
        'cbxEnrollmentDate
        '
        Me.cbxEnrollmentDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxEnrollmentDate.FormattingEnabled = True
        Me.cbxEnrollmentDate.Location = New System.Drawing.Point(610, 490)
        Me.cbxEnrollmentDate.Name = "cbxEnrollmentDate"
        Me.cbxEnrollmentDate.Size = New System.Drawing.Size(329, 37)
        Me.cbxEnrollmentDate.TabIndex = 22
        Me.cbxEnrollmentDate.Text = "Now()"
        '
        'cbxGraduationDate
        '
        Me.cbxGraduationDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbxGraduationDate.FormattingEnabled = True
        Me.cbxGraduationDate.Location = New System.Drawing.Point(610, 535)
        Me.cbxGraduationDate.Name = "cbxGraduationDate"
        Me.cbxGraduationDate.Size = New System.Drawing.Size(329, 37)
        Me.cbxGraduationDate.TabIndex = 23
        '
        'rbtnSQLserver
        '
        Me.rbtnSQLserver.AutoSize = True
        Me.rbtnSQLserver.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbtnSQLserver.Location = New System.Drawing.Point(49, 191)
        Me.rbtnSQLserver.Name = "rbtnSQLserver"
        Me.rbtnSQLserver.Size = New System.Drawing.Size(169, 33)
        Me.rbtnSQLserver.TabIndex = 24
        Me.rbtnSQLserver.TabStop = True
        Me.rbtnSQLserver.Text = "SQL Server"
        Me.rbtnSQLserver.UseVisualStyleBackColor = True
        '
        'rbtnMySQL
        '
        Me.rbtnMySQL.AutoSize = True
        Me.rbtnMySQL.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbtnMySQL.Location = New System.Drawing.Point(816, 191)
        Me.rbtnMySQL.Name = "rbtnMySQL"
        Me.rbtnMySQL.Size = New System.Drawing.Size(123, 33)
        Me.rbtnMySQL.TabIndex = 25
        Me.rbtnMySQL.TabStop = True
        Me.rbtnMySQL.Text = "MySQL"
        Me.rbtnMySQL.UseVisualStyleBackColor = True
        '
        'gbxInsertRecordSample
        '
        Me.gbxInsertRecordSample.Controls.Add(Me.lblLanguage)
        Me.gbxInsertRecordSample.Controls.Add(Me.tbxLanguage)
        Me.gbxInsertRecordSample.Controls.Add(Me.btnInsertLanguage)
        Me.gbxInsertRecordSample.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbxInsertRecordSample.Location = New System.Drawing.Point(40, 50)
        Me.gbxInsertRecordSample.Name = "gbxInsertRecordSample"
        Me.gbxInsertRecordSample.Size = New System.Drawing.Size(655, 113)
        Me.gbxInsertRecordSample.TabIndex = 26
        Me.gbxInsertRecordSample.TabStop = False
        Me.gbxInsertRecordSample.Text = "Insert Record Sample"
        '
        'FormStudentMasterDetail
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(974, 779)
        Me.Controls.Add(Me.gbxInsertRecordSample)
        Me.Controls.Add(Me.rbtnMySQL)
        Me.Controls.Add(Me.rbtnSQLserver)
        Me.Controls.Add(Me.cbxGraduationDate)
        Me.Controls.Add(Me.cbxEnrollmentDate)
        Me.Controls.Add(Me.btnClearFields)
        Me.Controls.Add(Me.btnDeleteRecord)
        Me.Controls.Add(Me.btnUpdateRecord)
        Me.Controls.Add(Me.btnInsertRecord)
        Me.Controls.Add(Me.lblGraduationDate)
        Me.Controls.Add(Me.lblEnrollmentDate)
        Me.Controls.Add(Me.lblStudentMajor)
        Me.Controls.Add(Me.tbxStudentMajor)
        Me.Controls.Add(Me.lblStudentName)
        Me.Controls.Add(Me.tbxStudentName)
        Me.Controls.Add(Me.lblStudentGPA)
        Me.Controls.Add(Me.tbxStudentGPA)
        Me.Controls.Add(Me.lblStudentID)
        Me.Controls.Add(Me.tbxStudentID)
        Me.Controls.Add(Me.dgvStudentRecords)
        Me.Name = "FormStudentMasterDetail"
        Me.Text = "Student Master Detail Form"
        CType(Me.dgvStudentRecords, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbxInsertRecordSample.ResumeLayout(False)
        Me.gbxInsertRecordSample.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents tbxLanguage As System.Windows.Forms.TextBox
    Friend WithEvents lblLanguage As System.Windows.Forms.Label
    Friend WithEvents btnInsertLanguage As System.Windows.Forms.Button
    Friend WithEvents dgvStudentRecords As System.Windows.Forms.DataGridView
    Friend WithEvents lblStudentID As System.Windows.Forms.Label
    Friend WithEvents tbxStudentID As System.Windows.Forms.TextBox
    Friend WithEvents lblStudentGPA As System.Windows.Forms.Label
    Friend WithEvents tbxStudentGPA As System.Windows.Forms.TextBox
    Friend WithEvents lblStudentName As System.Windows.Forms.Label
    Friend WithEvents tbxStudentName As System.Windows.Forms.TextBox
    Friend WithEvents lblStudentMajor As System.Windows.Forms.Label
    Friend WithEvents tbxStudentMajor As System.Windows.Forms.TextBox
    Friend WithEvents lblEnrollmentDate As System.Windows.Forms.Label
    Friend WithEvents lblGraduationDate As System.Windows.Forms.Label
    Friend WithEvents btnInsertRecord As System.Windows.Forms.Button
    Friend WithEvents btnUpdateRecord As System.Windows.Forms.Button
    Friend WithEvents btnDeleteRecord As System.Windows.Forms.Button
    Friend WithEvents btnClearFields As System.Windows.Forms.Button
    Friend WithEvents cbxEnrollmentDate As System.Windows.Forms.ComboBox
    Friend WithEvents cbxGraduationDate As System.Windows.Forms.ComboBox
    Friend WithEvents rbtnSQLserver As System.Windows.Forms.RadioButton
    Friend WithEvents rbtnMySQL As System.Windows.Forms.RadioButton
    Friend WithEvents gbxInsertRecordSample As System.Windows.Forms.GroupBox

End Class
