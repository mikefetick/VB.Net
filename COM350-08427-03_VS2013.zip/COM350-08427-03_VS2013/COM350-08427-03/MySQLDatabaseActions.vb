﻿Imports MySql.Data.MySqlClient

Public Class MySQLDatabaseActions
    Implements IDatabaseActions

    'Private connectionString As String = ""
    Private connectionString As String = "Server=localhost;Database=colemandevelopment;Uid=sqluser;Pwd=sqluser;"
    Private rowsAffected As Integer
    Private databasePath As String = ""
    Private sqlMask As String = "INSERT INTO Languages (Language) VALUES " & _
                                 "('{0}')"

    Public Function AddNewRecord(language As String) As Integer _
        Implements IDatabaseActions.AddNewRecord

        Dim sqlQuery As String = String.Format(sqlMask, language)
        Dim rowsAffected As Integer = 0

        Using conn As New MySqlConnection()
            conn.ConnectionString = connectionString
            conn.Open()

            Dim oleCmd As MySqlCommand = New MySqlCommand(sqlQuery, conn)
            rowsAffected = oleCmd.ExecuteNonQuery()

        End Using

        Return rowsAffected

    End Function
    Public Function UpdateNewRecord(ByVal languageID As Integer, ByVal language As String) As Integer _
        Implements IDatabaseActions.UpdateRecord
        Dim sqlQuery As String = "UPDATE Languages SET Language = @Language " & _
                                 "WHERE LanguageID = @LanguageID"

        Using conn As New MySqlConnection()
            conn.ConnectionString = connectionString
            conn.Open()

            Dim oleCmd As MySqlCommand = New MySqlCommand(sqlQuery, conn)
            oleCmd.Parameters.Add("@LanguageID", MySqlDbType.Int32).Value = languageID
            oleCmd.Parameters.Add("@Language", MySqlDbType.VarChar, 50).Value = language

            rowsAffected = oleCmd.ExecuteNonQuery()

        End Using

        Return rowsAffected
    End Function

    Public Function DeleteRecord(ByVal languageID As Integer) As Integer _
        Implements IDatabaseActions.DeleteRecord

        Dim sqlQuery As String = "DeleteLanguage"

        Using conn As New MySqlConnection()
            conn.ConnectionString = connectionString
            conn.Open()

            Dim oleCmd As MySqlCommand = New MySqlCommand(sqlQuery, conn)
            oleCmd.CommandType = CommandType.StoredProcedure
            oleCmd.Parameters.Add("p_language_id", MySqlDbType.Int32).Value = languageID

            rowsAffected = oleCmd.ExecuteNonQuery()

        End Using

        Return rowsAffected

    End Function

End Class
