﻿Imports System.Data
Imports System.Data.OleDb

Public Class DatabaseActions
    Implements IDatabaseActions

    'Private databasePath As String = "D:\DEVELOPMENT\COLEMAN\COM350\MOD05-2014\AccessFirst.accdb"
    Private databasePath As String = "C:\Users\Mike\Documents\ColemanU\mod09cis\COM350 Visual Basic Programming\Assignments\AccessFirst.accdb"
    Private sqlMask As String = "INSERT INTO Languages ([Language]) VALUES ('{0}')"
    Private sqlQuery As String = "INSERT INTO Languages ([Language]) VALUES ('PHP')"

    Public Function AddNewRecord(ByVal language As String) As Integer _
        Implements IDatabaseActions.AddNewRecord

        Dim sqlQuery = String.Format(sqlMask, language)
        Dim rowsAffected As Integer = 0
        Using conn As New OleDbConnection()
            conn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" & _
                                    "Data source=" & databasePath
            conn.Open()

            Dim oleCmd As OleDbCommand = New OleDbCommand(sqlQuery, conn)
            rowsAffected = oleCmd.ExecuteNonQuery()

        End Using

        Return rowsAffected

    End Function

    Public Function UpdateNewRecord(ByVal languageId As Integer, ByVal language As String) As Integer _
        Implements IDatabaseActions.UpdateRecord
        Return 0
    End Function

    Public Function DeleteRecord(ByVal languageID As Integer) As Integer _
        Implements IDatabaseActions.DeleteRecord
        Return 0
    End Function

    Public Sub OlderCode()
        Dim conn As OleDbConnection = New OleDbConnection()
        conn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" & _
                                "Data source=" & databasePath
        conn.Open()

        Dim oleCmd As OleDbCommand = New OleDbCommand(sqlQuery, conn)
        oleCmd.ExecuteNonQuery()

        conn.Close()
        conn = Nothing
    End Sub
End Class
