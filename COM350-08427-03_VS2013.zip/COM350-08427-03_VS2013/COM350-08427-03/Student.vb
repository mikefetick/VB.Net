﻿Public Class Student
    Public Property StudentID As String
    Public Property StudentName As String
    Public Property Major As String
    Public Property GPA As Decimal
    Public Property EnrollmentDate As DateTime
    Public Property GraduationDate As DateTime
End Class
