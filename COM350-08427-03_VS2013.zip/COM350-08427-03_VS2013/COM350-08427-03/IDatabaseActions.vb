﻿Public Interface IDatabaseActions
    Function AddNewRecord(ByVal language As String) As Integer
    Function UpdateRecord(ByVal languageID As Integer, ByVal language As String) As Integer
    Function DeleteRecord(ByVal languageID As Integer) As Integer
End Interface
