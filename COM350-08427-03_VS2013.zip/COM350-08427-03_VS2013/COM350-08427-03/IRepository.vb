﻿Imports System.ComponentModel

Public Interface IRepository
    Function GetAllRecords() As IListSource
    Function GetStudentByID(ByVal studentID As String) As Student
    Function InsertStudent(ByVal student As Student) As Boolean
    Function UpdateStudent(ByVal student As Student) As Boolean
    Function DeleteStudent(ByVal student As Student) As Boolean
End Interface
