﻿DELIMITER $$
-- DROP PROCEDURE IF EXISTS `DeleteLanguage`$$

CREATE PROCEDURE `DeleteLanguage`
(
        IN  p_language_id  INT(11) 
)
BEGIN 
    -- Comment that does nothing
    DELETE FROM languages WHERE  LanguageID = p_language_id; 

END$$

DELIMITER ;