﻿-- SQL Server
CREATE TABLE Students
(
    StudentID       VARCHAR(10) NOT NULL,
    StudentName     VARCHAR(32) NOT NULL,
    Major           VARCHAR(32) NOT NULL,
    GPA             DECIMAL(9, 4) NOT NULL,
    EnrollmentDate  DATETIME NOT NULL,
    GraduationDate  DATETIME NOT NULL
)