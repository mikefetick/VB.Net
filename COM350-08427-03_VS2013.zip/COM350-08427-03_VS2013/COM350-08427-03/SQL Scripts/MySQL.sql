﻿CREATE TABLE `Students`
(
	`StudentID`			VARCHAR(12) 	NOT NULL,
	`StudentName`   	VARCHAR(32)		NOT NULL,
	`Major`				VARCHAR(32)		NOT NULL,
	`GPA`				DECIMAL(9, 4)	NOT NULL,
	`EnrollmentDate` 	DATETIME		NOT NULL,
	`GraduationDate`	DATETIME		NOT NULL,
	PRIMARY KEY (`StudentID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;