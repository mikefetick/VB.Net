DROP TABLE IF EXISTS `Languages`;
CREATE TABLE IF NOT EXISTS `Languages` (
  `LanguageID` int(11) NOT NULL AUTO_INCREMENT,
  `Language` varchar(32) NOT NULL,
  PRIMARY KEY (`LanguageID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;


INSERT INTO Languages (Language) VALUES ('JavaScript');

SELECT * FROM Languages