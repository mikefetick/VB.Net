﻿' <summary>
' This is a test class for project UnitTestPatternSearcher
' and illustrated in ClassDiagram_PatternSearcher.cd
' The tests work with classes: PatternSearcher, SearchResults, and FoundResults
Imports System.Text
Imports Microsoft.VisualStudio.TestTools.UnitTesting
Imports System.IO
Imports UnitTestPatternSearcher.UnitTest_PatternSearcher

<TestClass()> Friend Class UnitTest_SearchResults
    Private _Matches As List(Of FoundResults)
    Private _Results As Integer
    Private _Time As Integer

#Region "Unit Tests"
    <TestInitialize()> _
    Public Sub Initialize()
        _Matches = New List(Of FoundResults)
        _Results = 0
        _Time = 0
    End Sub

    <TestMethod()> _
    Public Sub TestMethod1()
    End Sub
#End Region

#Region "Working Stuff"
    Private Function ValidateStartingLocation(path As String) As Boolean
        Return Directory.Exists(path)
    End Function

#End Region
End Class