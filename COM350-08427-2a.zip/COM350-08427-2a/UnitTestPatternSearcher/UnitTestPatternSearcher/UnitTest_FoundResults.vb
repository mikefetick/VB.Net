﻿' <summary>
' This is a test class for project UnitTestPatternSearcher
' and illustrated in ClassDiagram_PatternSearcher.cd
' The tests work with classes: PatternSearcher, SearchResults, and FoundResults
Imports System.Text
Imports Microsoft.VisualStudio.TestTools.UnitTesting
Imports System.IO

<TestClass()> Public Class UnitTest_FoundResults
    Private _BaseFileName As String
    Private _InputLine As String
    Private _LineNumber As Integer

#Region "Unit Tests"
    <TestInitialize()> _
    Public Sub Initialize()
        _BaseFileName = ""
        _InputLine = ""
        _LineNumber = 0
    End Sub

    <TestMethod()> _
    Public Sub File_Has_Data()
        Dim allLines() As String = File.ReadAllLines(_BaseFileName)
        'Assert.IsTrue(allLines.Length < 0, _BaseFileName & " should have data.")
        Assert.IsTrue(FileHasData(_BaseFileName), _BaseFileName & " should have data.")
    End Sub

    <TestMethod()> _
    Public Sub Read_Each_Line()
        Dim textIn As New StreamReader(
            New FileStream(_BaseFileName, FileMode.OpenOrCreate, FileAccess.Read))
        Dim count As Integer = 0

        Do While textIn.Peek <> -1
            Dim _Pattern As String = ""
            Dim aMatch As New List(Of FoundResults)
            Dim row As String = textIn.ReadLine
            If row.Contains(_Pattern) Then
                aMatch(count) = 
                count += 1
            End If

            Dim columns As String() = row.Split(CChar(","))
            song.Title = columns(0)
            'Call function getDuration() for min:sec string, not 'song.Duration = columns(1)
            song.Duration = getDuration()
            song.Artist = columns(2)
            song.Year = columns(3)
            song.Album = columns(4)
            song.Writers = columns(5)
            songs.Add(song)
        Loop
        textIn.Close()

    End Sub

#End Region

#Region "Working Stuff"
    Private Function FileHasData(path As String) As Boolean
        Dim allLines() As String = File.ReadAllLines(_BaseFileName)
        Return allLines.Length < 0
    End Function

#End Region
End Class
