﻿' This is a class in project UnitTestPatternSearcher
Imports System.IO
Friend Class PatternSearcher
    Private _FileType As String
    Private _IsCaseSensitive As Boolean
    Private _Pattern As String
    Private _StartingLocation As String

    Public Property FileType As String
        Get
            Return _FileType
        End Get
        Set(value As String)
            _FileType = value
        End Set
    End Property

    Public Property IsCaseSensitive As Boolean
        Get
            Return _IsCaseSensitive
        End Get
        Set(value As Boolean)
            _IsCaseSensitive = value
        End Set
    End Property

    Public Property Pattern As String
        Get
            Return _Pattern
        End Get
        Set(value As String)
            _Pattern = value
        End Set
    End Property

    Public Property StartingLocation As String
        Get
            Return _StartingLocation
        End Get
        Set(value As String)
            If ValidateStartingLocation(value) Then
                _StartingLocation = value
            End If
        End Set
    End Property

    Private Function ValidateStartingLocation(path As String) As Boolean
        Return Directory.Exists(path)
    End Function

    Public Function ExtractFilenameExtensionFromString(filename As String) As String
        Dim extractedExtension As String = ""
        Dim dotIndex As Integer = 0
        If filename <> Nothing And filename.Contains(".") Then
            dotIndex = filename.LastIndexOf(".")
            extractedExtension = filename.Substring(dotIndex, filename.Length - dotIndex)
            If ValidateFileType(extractedExtension) Then
                Return extractedExtension
            End If
        End If
        Return Nothing
    End Function

    Public Function ValidateFileType(filetype As String) As Boolean
        Dim isValidExtension As Boolean = False
        Dim validExtensions As IEnumerable(Of String) = {".*", ".txt", ".html", ".xml"}

        isValidExtension = validExtensions.Any(Function(x) x = filetype)
        Return isValidExtension
    End Function

    Public Function ValidateFileExists(filename As String) As Boolean
        'Public Sub Validate_File_Exists(ByVal directory As String, ByVal filename As String)
        Dim isFileFound As Boolean = False
        Dim di As New IO.DirectoryInfo(_StartingLocation)
        Dim aryFi As IO.FileInfo() = di.GetFiles(filename)
        Dim fi As IO.FileInfo

        For Each fi In aryFi
            isFileFound = True
        Next

        Return isFileFound
    End Function

    Public Function ValidatePattern(pattern As String) As Boolean
        If pattern.Length > 0 Then
            Return True
        End If
        Return False
    End Function

End Class
