﻿Public Class Form1

    Private Sub BrowseButton_Click(ByVal sender As System.Object, _
                                   ByVal e As System.EventArgs) Handles BrowseButton.Click

        Dim folderDlg As New FolderBrowserDialog
        folderDlg.ShowNewFolderButton = True
        If (folderDlg.ShowDialog() = DialogResult.OK) Then
            TextBox1.Text = folderDlg.SelectedPath
            Dim root As Environment.SpecialFolder = folderDlg.RootFolder
        End If

    End Sub
End Class
