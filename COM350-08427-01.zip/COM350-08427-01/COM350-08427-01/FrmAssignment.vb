﻿Imports COM350_08427_01.GetData
Public Class FrmAssignment
    Dim songIndex As Integer = 0
    Dim playIndex As Integer = -1
    Dim songTime As Integer = 0 'seconds
    Dim maxPlayTime As Integer = 1 'second
    Dim playTimeAvailable As Integer = 1 'second
    Dim playGapsDuration As Integer = 1 'second
    Dim playGapsCount As Integer = 0
    Dim folderDlg As New FolderBrowserDialog
    Public Shared Property songList As New List(Of Song)
    Public Shared Property playList As New List(Of Song)
    Public Shared Property testData As String = "..\..\data\Music\The Beatles\1"
    Protected Friend Sub FillSongListBox(songList As List(Of Song))
        'Test-12. Empty the playList when finished
        lbxSonglist.Items.Clear()
        For Each p As Song In songList
            lbxSonglist.Items.Add(p.GetDisplayText(vbTab))
        Next
    End Sub
    Protected Friend Sub FillPlayListBox(playList As List(Of Song))
        lbxPlaylist.Items.Clear()
        For Each q As Song In playList
            lbxPlaylist.Items.Add(q.GetDisplayText(vbTab))
        Next
    End Sub
    Public Sub ChangePlayGapsDuration(setting As Integer)
        'Set the playTimeAvailable with the maxPlayTimeChange
        Dim playGapsDurationChange As Integer = playGapsDuration - setting 'delta seconds
        playTimeAvailable = playTimeAvailable - (playGapsDurationChange * playGapsCount) 'change with the delta
        playGapsDuration = setting 'seconds
        'Set the label to display the changed play time available
        Me.lblAvailableDuration.Text = convertDuration(playTimeAvailable)
    End Sub
    Public Sub ChangeMaxPlayTime(setting As Integer)
        'Set the playTimeAvailable with the maxPlayTimeChange
        Dim maxPlayTimeChange As Integer = maxPlayTime - setting 'delta seconds
        playTimeAvailable = playTimeAvailable - maxPlayTimeChange 'change with the delta
        maxPlayTime = setting 'seconds
        'Set the label to display the changed play time available
        Me.lblAvailableDuration.Text = convertDuration(playTimeAvailable)
    End Sub
    Private Sub frmAssignment1_Load(sender As Object,
            e As EventArgs) Handles MyBase.Load, MyBase.Shown
        songList = GetData.getSongs(testData)
        If songList IsNot Nothing Then
            FillSongListBox(songList)
            ChangeMaxPlayTime(frmOptions.nudPlaylistLimit.Value * 60)
            'Set the song index of the first item as the next selected song on the song list
            lbxSonglist.SetSelected(0, True)
            Me.Size = New Size(752, 475)
        Else
            MessageBox.Show("No music files here: " & Dir())
            optionsForm.ShowDialog()
            If MessageBox.Show("No music files here: " & Dir() _
                               & "\nDo you want to change the settings?", "MP3 Player", _
                  MessageBoxButtons.YesNo, MessageBoxIcon.Question) _
                  = DialogResult.Yes Then
                optionsForm.ShowDialog()
            End If
        End If
    End Sub
    Friend WithEvents btnDropSongs As System.Windows.Forms.Button
    Friend WithEvents btnAddSong As System.Windows.Forms.Button
    Friend WithEvents btnDropSong As System.Windows.Forms.Button
    Friend WithEvents btnAddSongs As System.Windows.Forms.Button
    Friend WithEvents lblAvailableDuration As System.Windows.Forms.Label
    Friend WithEvents lblTimeElapsed As System.Windows.Forms.Label

    Private Sub lbxSonglist_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lbxSonglist.SelectedIndexChanged
        'Test-11. Buttons are active as needed - frmAssignment1.lbxSonglist_SelectedIndexChanged()
        songIndex = lbxSonglist.SelectedIndex
        If songIndex <> -1 Then
            btnAddSong.Enabled = True
        End If
    End Sub
    Private Sub lbxPlaylist_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lbxPlaylist.SelectedIndexChanged
        'Test-11. Buttons are active as needed - frmAssignment1.lbxPlaylist_SelectedIndexChanged()
        playIndex = lbxPlaylist.SelectedIndex

        If playIndex <> -1 Then
            btnDropSong.Enabled = True
        End If
    End Sub
    Private Sub btnDropSong_Click(sender As Object, e As EventArgs) Handles btnDropSong.Click
        'Pass the index of the selected song to drop the song from the play list
        playIndex = lbxPlaylist.SelectedIndex
        DropSong(playIndex)
    End Sub
    Private Function DropSong(playIndex As Integer) As Boolean
        If playIndex <> -1 Then

            Dim selectedSong As New Song
            selectedSong = playList(playIndex)
            'Test-07. Convert string of minute and seconds format into integer of time span - GetData.convertDurationString()
            songTime = convertDurationString(selectedSong.Duration) 'into seconds

            'A song gap does not exists for the last song; 
            'so determine the last song
            If Not (playTimeAvailable + songTime < maxPlayTime) Then
                playTimeAvailable = playTimeAvailable + songTime

                'Add the selected song to the song list
                songList.Add(selectedSong)
                Me.FillSongListBox(songList)

                'Remove the selected song from the play list
                playList.Remove(selectedSong)
                Me.FillPlayListBox(playList)
            Else
                'Test-09. If we clear the playlist it must reset the playGapsCount back to zero (frmAssignment1.btnDropSong_Click())
                playGapsCount -= 1
                'and add the song gap the rest of the time a song is added.
                playTimeAvailable = playTimeAvailable + frmOptions.nudPlayGaps.Value + songTime
                'Add the selected song to the song list
                songList.Add(selectedSong)
                Me.FillSongListBox(songList)

                'Remove the selected song from the play list
                playList.Remove(selectedSong)
                Me.FillPlayListBox(playList)
                'Set the song index as the next selected song on the play list
                'BUG-lbxPlaylist.SetSelected(playIndex + 1, True)
            End If

            'Update the playTimeAvailable in the lblAvailableDuration
            Me.lblAvailableDuration.Text = convertDuration(playTimeAvailable)

            'Dropped song is gone
            btnDropSong.Enabled = False
            Return True
        End If
        Return False
    End Function
    Private Sub btnAddSong_Click(sender As Object, e As EventArgs) Handles btnAddSong.Click
        'Pass the index of the selected song to add the song to the play list
        songIndex = lbxSonglist.SelectedIndex
        AddSong(songList, songIndex)
    End Sub
    Private Function AddSong(ByRef songList As List(Of Song), songIndex As Integer) As Boolean
        If songIndex <> -1 Then
            Dim selectedSong As New Song
            selectedSong = songList(songIndex)
            'Test-07. Convert string of minute and seconds format into integer of time span - GetData.convertDurationString()
            songTime = convertDurationString(selectedSong.Duration) 'into seconds

            'A song gap does not exists for the first song; 
            'so determine the first song
            If (playTimeAvailable = maxPlayTime) Then
                btnDropSong.Enabled = False

                'Test-08. Aggregate the song times for the playlist length
                If Not (playTimeAvailable - songTime) < 0 Then
                    playTimeAvailable = playTimeAvailable - songTime

                    'Sleep for enough time to display the selected song
                    lbxSonglist.SetSelected(songIndex, True)
                    Threading.Thread.Sleep(250) 'milliseconds
                    'Add the selected song to the play list
                    playList.Add(selectedSong)
                    Me.FillPlayListBox(playList)
                    Threading.Thread.Sleep(250) 'milliseconds

                    'Remove the selected song from the song list
                    songList.Remove(selectedSong)
                    Me.FillSongListBox(songList)
                    Threading.Thread.Sleep(250) 'milliseconds

                    'Update the playTimeAvailable in the lblAvailableDuration
                    Me.lblAvailableDuration.Text = convertDuration(playTimeAvailable)

                    'Added song is still selected and can be dropped
                    btnDropSong.Enabled = True
                Else
                    If MessageBox.Show("You only have " & convertDuration(playTimeAvailable) _
                                       & " (min:sec) available on your playlist" _
                                       & "\nDo you want to change the settings?", "MP3 Player", _
                          MessageBoxButtons.YesNo, MessageBoxIcon.Question) _
                          = DialogResult.Yes Then
                        optionsForm.ShowDialog()
                    End If
                    Return False
                End If
            Else
                'Test-04. My playlist may be greater than 20:00 (nudPlaylistLimit.max = 60)
                If Not (playTimeAvailable - frmOptions.nudPlayGaps.Value - songTime) < 0 Then
                    'Test-09. If we clear the playlist it must reset the playGapsCount back to zero (frmAssignment1.btnDropSong_Click())
                    playGapsCount += 1
                    'Test-08. Aggregate the song times for the playlist length
                    'and subtract the song gap the rest of the time a song is added.
                    playTimeAvailable = playTimeAvailable - frmOptions.nudPlayGaps.Value - songTime

                    'Sleep for enough time to display the selected song
                    'lbxPlaylist.SetSelected(songIndex, True)
                    'Threading.Thread.Sleep(250) 'milliseconds
                    'Add the selected song to the play list
                    playList.Add(selectedSong)
                    Me.FillPlayListBox(playList)

                    'Remove the selected song from the song list
                    songList.Remove(selectedSong)
                    Me.FillSongListBox(songList)

                    'Update the playTimeAvailable in the lblAvailableDuration
                    Me.lblAvailableDuration.Text = convertDuration(playTimeAvailable)

                    'Added song is still selected and can be dropped
                    btnDropSong.Enabled = True
                    'Set the song index as the next selected song on the song list
                    'BUG-lbxSonglist.SetSelected(songIndex + 1, True)
                Else
                    If MessageBox.Show("You only have " & convertDuration(playTimeAvailable) _
                                       & " (min:sec) available on your playlist" _
                                       & "\nDo you want to change the settings?", "MP3 Player", _
                          MessageBoxButtons.YesNo, MessageBoxIcon.Question) _
                          = DialogResult.Yes Then
                        optionsForm.ShowDialog()
                    End If
                    Return False
                End If
            End If
        End If
        Return True
    End Function
    Friend WithEvents lblTestResults As System.Windows.Forms.Label
    Private Sub lblTestResults_Click(sender As Object, e As EventArgs) Handles lblTestResults.Click
        'DisplayTestResults()
    End Sub
    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        'Close dialog box
        Me.Close()
        'Exit
        'Application.Exit
    End Sub
    Private Sub btnAddSongs_Click(sender As Object, e As EventArgs) Handles btnAddSongs.Click
        'Pass the index of the selected song to add the song to the play list
        Dim songListCount As Integer = lbxSonglist.Items.Count
        Dim i As Integer = 0
        Dim j As Integer = 0
        'For Each songIndex As Song In songList
        For i = 0 To songListCount - 1
            If Not AddSong(songList, j) Then
                Exit For
            Else
                'lbxSonglist.SetSelected(i, True)
                'Threading.Thread.Sleep(500) 'milliseconds
            End If
        Next
    End Sub

    Private Sub btnDropSongs_Click(sender As Object, e As EventArgs) Handles btnDropSongs.Click
        'Pass the index of the selected song to drop the song from the play list
        Dim playListCount As Integer = lbxPlaylist.Items.Count
        Dim i As Integer = 0
        Dim j As Integer = 0
        'For Each songIndex As Song In songList
        For i = 0 To playListCount - 1
            If Not DropSong(j) Then
                Exit For
            Else
                'lbxPlaylist.SetSelected(i, True)
                'Threading.Thread.Sleep(500) 'milliseconds
            End If
        Next

        playIndex = lbxPlaylist.SelectedIndex
        DropSong(playIndex)
    End Sub
End Class