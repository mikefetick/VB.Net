﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmOptions
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pnlOptions = New System.Windows.Forms.Panel()
        Me.lblCoverSecs = New System.Windows.Forms.Label()
        Me.lblPlaylistUnits = New System.Windows.Forms.Label()
        Me.lblDurUnits = New System.Windows.Forms.Label()
        Me.btnDefault = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.nudPlaylistLimit = New System.Windows.Forms.NumericUpDown()
        Me.lblPlaylistLimit = New System.Windows.Forms.Label()
        Me.nudPlayGaps = New System.Windows.Forms.NumericUpDown()
        Me.lblDurSongGaps = New System.Windows.Forms.Label()
        Me.lblStartingLocation = New System.Windows.Forms.Label()
        Me.btnLaunch = New System.Windows.Forms.Button()
        Me.tbxStartingLocation = New System.Windows.Forms.TextBox()
        Me.pnlOptions.SuspendLayout()
        CType(Me.nudPlaylistLimit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudPlayGaps, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pnlOptions
        '
        Me.pnlOptions.Controls.Add(Me.lblCoverSecs)
        Me.pnlOptions.Controls.Add(Me.lblPlaylistUnits)
        Me.pnlOptions.Controls.Add(Me.lblDurUnits)
        Me.pnlOptions.Controls.Add(Me.btnDefault)
        Me.pnlOptions.Controls.Add(Me.btnCancel)
        Me.pnlOptions.Controls.Add(Me.btnSave)
        Me.pnlOptions.Controls.Add(Me.nudPlaylistLimit)
        Me.pnlOptions.Controls.Add(Me.lblPlaylistLimit)
        Me.pnlOptions.Controls.Add(Me.nudPlayGaps)
        Me.pnlOptions.Controls.Add(Me.lblDurSongGaps)
        Me.pnlOptions.Controls.Add(Me.lblStartingLocation)
        Me.pnlOptions.Controls.Add(Me.btnLaunch)
        Me.pnlOptions.Controls.Add(Me.tbxStartingLocation)
        Me.pnlOptions.Location = New System.Drawing.Point(5, 5)
        Me.pnlOptions.Name = "pnlOptions"
        Me.pnlOptions.Size = New System.Drawing.Size(850, 350)
        Me.pnlOptions.TabIndex = 0
        '
        'lblCoverSecs
        '
        Me.lblCoverSecs.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblCoverSecs.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblCoverSecs.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCoverSecs.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblCoverSecs.Location = New System.Drawing.Point(312, 207)
        Me.lblCoverSecs.Name = "lblCoverSecs"
        Me.lblCoverSecs.Size = New System.Drawing.Size(64, 31)
        Me.lblCoverSecs.TabIndex = 9
        Me.lblCoverSecs.Text = ":00"
        '
        'lblPlaylistUnits
        '
        Me.lblPlaylistUnits.AutoSize = True
        Me.lblPlaylistUnits.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPlaylistUnits.Location = New System.Drawing.Point(417, 205)
        Me.lblPlaylistUnits.Name = "lblPlaylistUnits"
        Me.lblPlaylistUnits.Size = New System.Drawing.Size(168, 31)
        Me.lblPlaylistUnits.TabIndex = 10
        Me.lblPlaylistUnits.Text = "(mins : secs)"
        '
        'lblDurUnits
        '
        Me.lblDurUnits.AutoSize = True
        Me.lblDurUnits.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDurUnits.Location = New System.Drawing.Point(355, 140)
        Me.lblDurUnits.Name = "lblDurUnits"
        Me.lblDurUnits.Size = New System.Drawing.Size(221, 31)
        Me.lblDurUnits.TabIndex = 6
        Me.lblDurUnits.Text = "seconds duration"
        '
        'btnDefault
        '
        Me.btnDefault.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDefault.Location = New System.Drawing.Point(525, 275)
        Me.btnDefault.Name = "btnDefault"
        Me.btnDefault.Size = New System.Drawing.Size(150, 50)
        Me.btnDefault.TabIndex = 13
        Me.btnDefault.Text = "&Default"
        Me.btnDefault.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.Location = New System.Drawing.Point(350, 275)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(150, 50)
        Me.btnCancel.TabIndex = 12
        Me.btnCancel.Text = "&Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnSave
        '
        Me.btnSave.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSave.Location = New System.Drawing.Point(175, 275)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(150, 50)
        Me.btnSave.TabIndex = 11
        Me.btnSave.Text = "&Save"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'nudPlaylistLimit
        '
        Me.nudPlaylistLimit.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.nudPlaylistLimit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nudPlaylistLimit.Location = New System.Drawing.Point(280, 205)
        Me.nudPlaylistLimit.Maximum = New Decimal(New Integer() {60, 0, 0, 0})
        Me.nudPlaylistLimit.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudPlaylistLimit.Name = "nudPlaylistLimit"
        Me.nudPlaylistLimit.Size = New System.Drawing.Size(130, 38)
        Me.nudPlaylistLimit.TabIndex = 8
        Me.nudPlaylistLimit.Value = New Decimal(New Integer() {20, 0, 0, 0})
        '
        'lblPlaylistLimit
        '
        Me.lblPlaylistLimit.AutoSize = True
        Me.lblPlaylistLimit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPlaylistLimit.Location = New System.Drawing.Point(50, 205)
        Me.lblPlaylistLimit.Name = "lblPlaylistLimit"
        Me.lblPlaylistLimit.Size = New System.Drawing.Size(165, 31)
        Me.lblPlaylistLimit.TabIndex = 7
        Me.lblPlaylistLimit.Text = "Playlist Limit"
        '
        'nudPlayGaps
        '
        Me.nudPlayGaps.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nudPlayGaps.Location = New System.Drawing.Point(280, 140)
        Me.nudPlayGaps.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.nudPlayGaps.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.nudPlayGaps.Name = "nudPlayGaps"
        Me.nudPlayGaps.Size = New System.Drawing.Size(70, 38)
        Me.nudPlayGaps.TabIndex = 5
        Me.nudPlayGaps.Value = New Decimal(New Integer() {5, 0, 0, 0})
        '
        'lblDurSongGaps
        '
        Me.lblDurSongGaps.AutoSize = True
        Me.lblDurSongGaps.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDurSongGaps.Location = New System.Drawing.Point(50, 140)
        Me.lblDurSongGaps.Name = "lblDurSongGaps"
        Me.lblDurSongGaps.Size = New System.Drawing.Size(204, 31)
        Me.lblDurSongGaps.TabIndex = 4
        Me.lblDurSongGaps.Text = "Between Songs"
        '
        'lblStartingLocation
        '
        Me.lblStartingLocation.AutoSize = True
        Me.lblStartingLocation.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStartingLocation.Location = New System.Drawing.Point(50, 75)
        Me.lblStartingLocation.Name = "lblStartingLocation"
        Me.lblStartingLocation.Size = New System.Drawing.Size(218, 31)
        Me.lblStartingLocation.TabIndex = 2
        Me.lblStartingLocation.Text = "Starting Location"
        '
        'btnLaunch
        '
        Me.btnLaunch.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLaunch.Location = New System.Drawing.Point(670, 121)
        Me.btnLaunch.Name = "btnLaunch"
        Me.btnLaunch.Size = New System.Drawing.Size(150, 50)
        Me.btnLaunch.TabIndex = 0
        Me.btnLaunch.Text = "Launch"
        Me.btnLaunch.UseVisualStyleBackColor = True
        '
        'tbxStartingLocation
        '
        Me.tbxStartingLocation.Location = New System.Drawing.Point(280, 75)
        Me.tbxStartingLocation.Name = "tbxStartingLocation"
        Me.tbxStartingLocation.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal
        Me.tbxStartingLocation.Size = New System.Drawing.Size(535, 31)
        Me.tbxStartingLocation.TabIndex = 3
        Me.tbxStartingLocation.Text = "..\..\data\Music\The Beatles\1"
        '
        'frmOptions
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(861, 361)
        Me.Controls.Add(Me.pnlOptions)
        Me.Name = "frmOptions"
        Me.Text = "Options"
        Me.pnlOptions.ResumeLayout(False)
        Me.pnlOptions.PerformLayout()
        CType(Me.nudPlaylistLimit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudPlayGaps, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pnlOptions As System.Windows.Forms.Panel
    Friend WithEvents btnDefault As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents nudPlaylistLimit As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblPlaylistLimit As System.Windows.Forms.Label
    Friend WithEvents nudPlayGaps As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblDurSongGaps As System.Windows.Forms.Label
    Friend WithEvents lblStartingLocation As System.Windows.Forms.Label
    Friend WithEvents btnLaunch As System.Windows.Forms.Button
    Friend WithEvents tbxStartingLocation As System.Windows.Forms.TextBox
    Friend WithEvents lblPlaylistUnits As System.Windows.Forms.Label
    Friend WithEvents lblDurUnits As System.Windows.Forms.Label
    Friend WithEvents lblCoverSecs As System.Windows.Forms.Label
End Class
