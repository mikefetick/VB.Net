﻿Public Class Song
    Public Property Title As String
    Public Property Duration As String
    Public Sub New()

    End Sub
    Public Sub New(title As String, duration As String)
        Me.Title = title
        Me.Duration = duration
    End Sub
    Public Function GetDisplayText(sep As String) As String
        Dim text As String = String.Format("{0,-51} {1}{2}", Title, sep, Duration)
        'Dim text As String = Title & sep & Duration
        Return text
    End Function

End Class
