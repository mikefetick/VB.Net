﻿'Imports System.Windows.Forms
Imports System.IO
Imports COM350_08427_01.DatafileUtility
Imports NUnit.Framework
Public Class GetData
    Public Shared Property optionsForm As New frmOptions
    'Public Shared Property Title As String = "Error with Data Source"
    Public Shared Property rand As New Random
    Public Shared Property playTimeAvailableString As String = "00:00"
    Public Shared Function pseudoData()
        'Test-06. Generate a random number (between 120 to 900) for the duration - GetData.pseudoData()
        'Limit random songTime to 120-900 secs (2-15 mins)
        Dim lower As Integer = 120
        Dim upper As Integer = 900
        Dim songTime As Integer = rand.Next(lower, upper)
        'Assert.ByVal(GetSetting("COM350-084270-01", frmMP3Player.nudSongGaps.Minimum), "The songTime should be an Integer.")
        Return songTime
    End Function
    Public Shared Function getDuration() As String
        'Call function pseudoData() to get random number within (120-900) seconds
        Dim songTime As Integer = pseudoData()
        'Test-05. Every song must have min/secs - GetData.convertDuration()
        Return convertDuration(songTime)
    End Function
    Public Shared Function convertDuration(songTime As Integer)
        'Test-05. Every song must have min/secs - GetData.convertDuration()
        Dim songMins As Integer = songTime \ 60
        Dim songSecs As Integer = songTime Mod 60

        'Song duration string, e.g. 90 secs is 01:30
        Dim songDurStr As String = ""
        If Not (songMins > 9) Then
            songDurStr = "0"
        End If
        songDurStr = songDurStr & songMins & ":"
        If Not (songSecs > 9) Then
            songDurStr = songDurStr & "0"
        End If
        songDurStr = songDurStr & songSecs
        Return songDurStr

    End Function
    Public Shared Function convertDurationString(songDurStr As String)
        'Test-07. Convert string of minute and seconds format into integer of time span - GetData.convertDurationString()
        Dim asciiValue As Integer = 0
        Dim mins2_0to5 As Char = songDurStr.Substring(0, 1)
        Dim mins1_0to9 As Char = songDurStr.Substring(1, 1)
        Dim secs2_0to5 As Char = songDurStr.Substring(3, 1)
        Dim secs1_0to9 As Char = songDurStr.Substring(4, 1)
        Dim timeMins As Integer = 0
        Dim timeMins1 As Integer = 0
        Dim timeMins2 As Integer = 0
        Dim timeSecs As Integer = 0
        Dim timeSecs1 As Integer = 0
        Dim timeSecs2 As Integer = 0
        Dim timeDuration As Integer = 0
        Dim convertsGood As Boolean = False

        'Convert ?m of mm:ss into minutes
        asciiValue = Asc(mins2_0to5)
        'If between 0 to 5
        If (asciiValue >= 48) And (asciiValue <= 53) Then
            timeMins2 = Int32.Parse(mins2_0to5) * 10
        End If

        'Convert m? of mm:ss into minutes
        asciiValue = Asc(mins1_0to9)
        'If between 0 to 9
        If (asciiValue >= 48) And (asciiValue <= 57) Then
            timeMins1 = Int32.Parse(mins1_0to9)
        End If
        timeMins = timeMins2 + timeMins1

        'Convert ?s of mm:ss into seconds
        asciiValue = Asc(secs2_0to5)
        'If between 0 to 5
        If (asciiValue >= 48) And (asciiValue <= 53) Then
            timeSecs2 = Int32.Parse(secs2_0to5) * 10
        End If

        'Convert s? of mm:ss into seconds
        asciiValue = Asc(secs1_0to9)
        'If between 0 to 9
        If (asciiValue >= 48) And (asciiValue <= 57) Then
            timeSecs1 = Int32.Parse(secs1_0to9)
        End If
        timeSecs = timeSecs2 + timeSecs1

        'Tally the time duration mm:ss into seconds
        timeDuration = (timeMins * 60) + timeSecs
        Return timeDuration

    End Function
    Public Shared Function MusicFileHasProperExtension(musicFile As String) As Boolean
        Dim isValidExtension As Boolean = False
        Dim fi As FileInfo = New FileInfo(musicFile)
        Dim extension As String = fi.Extension
        Dim validExtensions = {".m4a", ".mp3", ".wma"}
        isValidExtension = validExtensions.Any(Function(x) x = extension)
        Return isValidExtension
    End Function
    Public Sub ListDir(ByVal directory As String, ByVal fileType As String)
        Dim di As New IO.DirectoryInfo(directory)
        Dim aryFi As IO.FileInfo() = di.GetFiles(fileType)
        Dim fi As IO.FileInfo

        For Each fi In aryFi
            'ListBox1.Items.Add(fi.Name)
        Next
    End Sub
    Public Shared Function getSongs(dir As String) As List(Of Song)
        'Going to return songs
        Dim songs As List(Of Song) = New List(Of Song)()
        'Test-01. Ensure the directory is valid (GetData::DatafileUtility.DoesDirectoryExists)

        'Dim dir As String = frmOptions.tbxStartingLocation.Text
        If DoesDirectoryExists.ValidateFolderLocation(dir) Then

            Dim fiDir As New IO.DirectoryInfo(dir)
            Dim aryFi As IO.FileInfo() = fiDir.GetFiles()
            For Each existingFile In aryFi
                'Test-02. A directory must have music files
                If MusicFileHasProperExtension(existingFile.ToString) Then
                    'Object Initializers
                    Dim thisSong As Song = New Song()
                    thisSong.Title = existingFile.Name
                    thisSong.Duration = getDuration()
                    songs.Add(thisSong)
                End If
            Next
        Else
            MessageBox.Show("Directory does not exists: " & dir)
            optionsForm.ShowDialog()
        End If
        Return songs

    End Function

End Class
<TestFixture> _
Public Class TestCases_GetData
    <Test> _
    Public Sub Music_File_Has_Proper_Extension()
        Dim dir As String = "C:\Users\Mike\Music\The Beatles\1"
        Dim musicFile = dir & "\" & "01 Love Me Do.m4a"
        Dim isValidExtension As Boolean = False
        If File.Exists(musicFile) Then
            Dim fi As FileInfo = New FileInfo(musicFile)
            Dim extension As String = fi.Extension
            'Dim directory As String = fi.DirectoryName
            'Dim name As String = fi.Name
            Dim validExtensions = {".m4a", ".mp3", ".wma"}
            isValidExtension = validExtensions.Any(Function(x) x = extension)
        End If
        Assert.IsTrue(isValidExtension, "The music file has a valid extension")
    End Sub
    <Test> _
    Public Sub Does_Formatted_String_Match_Integer_Of_Time_Span()
        'Test-05. Every song must have min/secs - GetData.convertDuration(69)
        Dim durationString As String = GetData.convertDuration(69).ToString
        Assert.IsTrue(durationString.Equals("01:09"), _
            "The song duration of 69 seconds should be shown as 01:09.")
    End Sub
    <Test> _
    Public Sub Does_Integer_Of_Time_Span_Match_Formatted_String()
        'Test-07. Convert number into minute and seconds format - GetData.convertDurationString("12:03")
        Dim durationInteger As Integer = GetData.convertDurationString("12:03")
        Assert.IsTrue(durationInteger = 723, _
            "The song duration of 12:03 should equate to 723 seconds.")
    End Sub
    <Test> _
    Public Sub Generate_Random_Number()
        'Arrange
        Dim firstNumber As Integer = GetData.pseudoData()
        Dim secondNumber As Integer = GetData.pseudoData()
        ' …
        'Act
        Dim NumbersAreNotEqual As Boolean = firstNumber <> secondNumber
        '…
        ' Assert
        Assert.That(firstNumber <> secondNumber, "The numbers should not be equal.")
    End Sub
End Class
