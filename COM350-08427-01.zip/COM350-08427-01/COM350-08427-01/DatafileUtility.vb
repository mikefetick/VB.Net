﻿Imports System.IO
Imports NUnit.Framework
<TestFixture> _
Public Class DatafileUtility
    Public Class DoesDirectoryExists
        <Test> _
        Public Sub Directory_Does_Exists()
            ' Arrange
            Dim testFolder As String = "..\..\data"
            ' …
            ' Act
            Dim isValidFolder = Directory.Exists(testFolder)
            ' …
            ' Assert
            'Assert.True(isValidFolder, "The folder should exist.")
            Assert.True(ValidateFolderLocation(testFolder), "The folder should exist.")
        End Sub

        <Test> _
        Public Sub Directory_Does_Not_Exist()
            ' Arrange
            Dim testFolder As String = "C:\TEMP\Starting Location Whatever"
            Dim isValidFolder = Directory.Exists(testFolder)
            ' …
            ' Assert
            'Assert.False(isValidFolder, “The folder should not exist.”
            Assert.False(ValidateFolderLocation(testFolder), "The folder should not exist.")
            ' …
            ' Act
        End Sub

        Public Shared Function ValidateFolderLocation(ByVal location As String) As Boolean
            Return Directory.Exists(location)
        End Function

    End Class
    <TestFixture> _
    Public Class DoesFileExists
        <Test> _
        Public Sub File_Does_Exists()
            ' Arrange
            ' Dim testFolder As String = "C:\TEMP\Starting Location"
            Dim testFolder As String = "..\..\data"
            Dim testFile As String = testFolder & "\beatlesSongs.csv"
            ' …
            ' Act
            Dim isValidFile = File.Exists(testFile)
            ' …
            ' Assert
            'Assert.True(isValidFile, "The folder should exist.")
            Assert.True(ValidateFilename(testFile), "The file should exist.")
        End Sub
        <Test> _
        Public Sub File_Does_Not_Exists()
            ' Arrange
            Dim testFolder As String = "C:\TEMP\Starting Location"
            Dim testFile As String = testFolder & "\wrongname.csv"
            ' …
            ' Act
            Dim isValidFile = File.Exists(testFile)
            ' …
            ' Assert
            'Assert.False(isValidFile, "The file should not exist.")
            Assert.False(ValidateFilename(testFile), "The file should not exist.")
        End Sub
        Public Shared Function ValidateFilename(ByVal filename As String) As Boolean
            Return File.Exists(filename)
        End Function

    End Class

End Class
