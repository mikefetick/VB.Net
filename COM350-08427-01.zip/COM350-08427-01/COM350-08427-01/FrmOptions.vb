﻿Imports System.IO
Imports COM350_08427_01.DatafileUtility
Imports COM350_08427_01.GetData
Public Class frmOptions
    Dim songList As New List(Of Song)
    Dim playList As New List(Of Song)
    Dim maxPlayTimeDefault As Integer = 20 'minutes
    Dim playGapsDurationDefault As Integer = 5 'seconds
    Dim folderDlg As New FolderBrowserDialog
    Dim tempTbxStartingLocation As String = ""
    Dim tempNudPlayGaps As Integer = 0
    Dim tempNudPlaylistLimit As Integer = 0
    Private Sub FrmOptions_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim yourToolTip As ToolTip = New ToolTip()
        'yourToolTip.ToolTipIcon = ToolTipIcon.Info
        yourToolTip.IsBalloon = True

        yourToolTip.SetToolTip(tbxStartingLocation, "Default: test data, Launch to browse another location")
        yourToolTip.SetToolTip(btnLaunch, "Default: test data, Launch to browse another location")
        yourToolTip.SetToolTip(nudPlaylistLimit, "1-60 minutes, changes in effect upon Save")
        yourToolTip.SetToolTip(nudPlayGaps, "1-10 seconds, changes in effect upon Save")
        'Load default values
        tempTbxStartingLocation = tbxStartingLocation.Text
        tempNudPlayGaps = nudPlayGaps.Value
        tempNudPlaylistLimit = nudPlaylistLimit.Value
    End Sub
    Private Sub btnLaunch_Click(ByVal sender As System.Object, _
                                   ByVal e As System.EventArgs) Handles btnLaunch.Click
        'For user to search for music, set root of folder dialog to users desktop
        folderDlg.RootFolder = Environment.SpecialFolder.DesktopDirectory
        folderDlg.ShowNewFolderButton = True
        If (folderDlg.ShowDialog() = DialogResult.OK) Then
            tbxStartingLocation.Text = folderDlg.SelectedPath
            Dim root As Environment.SpecialFolder = folderDlg.RootFolder
        End If
    End Sub
    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        'Save the changes from this form throughout the application
        FrmAssignment.ChangeMaxPlayTime(nudPlaylistLimit.Value * 60)
        FrmAssignment.ChangePlayGapsDuration(nudPlayGaps.Value)
        songList = GetData.getSongs(tbxStartingLocation.Text)
        If songList IsNot Nothing Then
            FrmAssignment.songList = songList
            FrmAssignment.FillSongListBox(songList)
            'Set the song index of the first item as the next selected song on the song list
            'FrmAssignment.lbxSonglist.SetSelected(0, True)
            'Close dialog box
            Me.Close()
        Else
            MessageBox.Show("No music files here: " & Dir())
            optionsForm.ShowDialog()
        End If
    End Sub
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        'Cancel
        'Set values back to when form was loaded
        tbxStartingLocation.Text = tempTbxStartingLocation
        nudPlayGaps.Value = tempNudPlayGaps
        nudPlaylistLimit.Value = tempNudPlaylistLimit
        'Close dialog box
        Me.Close()
    End Sub
    Private Sub btnDefault_Click(sender As Object, e As EventArgs) Handles btnDefault.Click
        'Set values back to factory default
        tbxStartingLocation.Text = FrmAssignment.testData
        'Set play list limit to default
        nudPlaylistLimit.Value = maxPlayTimeDefault
        FrmAssignment.ChangeMaxPlayTime(maxPlayTimeDefault * 60)
        'Set play gaps duration to default
        nudPlayGaps.Value = playGapsDurationDefault
        FrmAssignment.ChangePlayGapsDuration(playGapsDurationDefault)
    End Sub
    Private Sub ValidateDirectoryExits()
        If Not Directory.Exists(tbxStartingLocation.Text) Then
        Else
            MessageBox.Show("Directory does not exists: " & Dir())
            tbxStartingLocation.Focus()
        End If
    End Sub
End Class