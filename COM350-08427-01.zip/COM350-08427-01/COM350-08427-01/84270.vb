Imports System.IO
Imports NUnit.Framework
<TestFixture> _
Public Class TestCases_frmAssignment1

    'Test-01. Ensure the directory is valid (GetData::DatafileUtility.DoesDirectoryExists)
    Public Class DoesDirectoryExists
        <Test> _
        Public Sub Directory_Does_Exists()
            ' Arrange
            Dim testFolder As String = "..\..\data"
            ' �
            ' Act
            Dim isValidFolder = Directory.Exists(testFolder)
            ' �
            ' Assert
            'Assert.True(isValidFolder, "The folder should exist.")
            Assert.True(ValidateFolderLocation(testFolder), "The folder should exist.")
        End Sub
        <Test> _
        Public Sub Directory_Does_Not_Exist()
            ' Arrange
            Dim testFolder As String = "C:\TEMP\Starting Location Whatever"
            Dim isValidFolder = Directory.Exists(testFolder)
            ' �
            ' Assert
            'Assert.False(isValidFolder, �The folder should not exist.�
            Assert.False(ValidateFolderLocation(testFolder), "The folder should not exist.")
            ' �
            ' Act
        End Sub
        Public Shared Function ValidateFolderLocation(ByVal location As String) As Boolean
            Return Directory.Exists(location)
        End Function
    End Class

    'Test-02a. A directory must have files (music files)
    Public Class DoesFileExists
        <Test> _
        Public Sub File_Does_Exists()
            ' Arrange
            ' Dim testFolder As String = "C:\TEMP\Starting Location"
            Dim testFolder As String = "."
            Dim testFile As String = testFolder & "\84270.vb"
            ' �
            ' Act
            Dim isValidFile = File.Exists(testFile)
            ' �
            ' Assert
            'Assert.True(isValidFile, "The folder should exist.")
            Assert.True(ValidateFilename(testFile), "The file should exist.")
        End Sub
        <Test> _
        Public Sub File_Does_Not_Exists()
            ' Arrange
            Dim testFolder As String = "C:\TEMP\Starting Location"
            Dim testFile As String = testFolder & "\wrongname.csv"
            ' �
            ' Act
            Dim isValidFile = File.Exists(testFile)
            ' �
            ' Assert
            'Assert.False(isValidFile, "The file should not exist.")
            Assert.False(ValidateFilename(testFile), "The file should not exist.")
        End Sub
        Public Shared Function ValidateFilename(ByVal filename As String) As Boolean
            Return File.Exists(filename)
        End Function
    End Class

    'Test-02b. A directory must have music files
    <Test> _
    Public Sub Music_File_Has_Proper_Extension()
        Dim dir As String = "C:\Users\Mike\Music\The Beatles\1"
        Dim musicFile = dir & "\" & "01 Love Me Do.m4a"
        Dim isValidExtension As Boolean = False
        If File.Exists(musicFile) Then
            Dim fi As FileInfo = New FileInfo(musicFile)
            Dim extension As String = fi.Extension
            Dim validExtensions = {".m4a", ".mp3", ".wma"}
            isValidExtension = validExtensions.Any(Function(x) x = extension)
        End If
        Assert.IsTrue(isValidExtension, "The music file has a valid extension")
    End Sub
    Public Shared Function MusicFileHasProperExtension(musicFile As String) As Boolean
        Dim isValidExtension As Boolean = False
        If File.Exists(musicFile) Then
            Dim fi As FileInfo = New FileInfo(musicFile)
            Dim extension As String = fi.Extension
            'Dim directory As String = fi.DirectoryName
            'Dim name As String = fi.Name
            Dim validExtensions = {".mp3", ".wma", ".m4a"}
            isValidExtension = validExtensions.Any(Function(x) x = extension)
        End If
        Return isValidExtension
    End Function

    'Test-03. Gap duration must be greater than zero (numericUpDown control nudSongGaps.Minimum = 1)
    <Test> _
    Public Sub Is_Song_Gap_Greater_Than_Zero()
        Assert.Greater(Int32.Parse(frmOptions.nudPlayGaps.Minimum), 0, _
                    "The song gap duration must be greater than zero.")
    End Sub

    'Test-04. My playlist must be at least 20:00 (numericUpDown control nudPlaylistLimit.Minimum = 20)
    <Test> _
    Public Sub Is_Playlist_Duration_At_Least_Twenty_Minutes()
        Assert.GreaterOrEqual(Int32.Parse(frmOptions.nudPlaylistLimit.Minimum), 20, _
                    "The play list duration must be at least twenty minutes.")
    End Sub

    'Test-05. Every song must have min/secs - GetData.convertDuration(69)
    <Test> _
    Public Sub Does_Formatted_String_Match_Integer_Of_Time_Span()
        Dim durationString As String = GetData.convertDuration(69).ToString
        Assert.IsTrue(durationString.Equals("01:09"), _
            "The song duration of 69 seconds should be shown as 01:09.")
    End Sub
    Public Shared Function convertDuration(songTime As Integer)
        'Test-05. Every song must have min/secs - GetData.convertDuration()
        Dim songMins As Integer = songTime \ 60
        Dim songSecs As Integer = songTime Mod 60

        'Song duration string, e.g. 90 secs is 01:30
        Dim songDurStr As String = ""
        If Not (songMins > 9) Then
            songDurStr = "0"
        End If
        songDurStr = songDurStr & songMins & ":"
        If Not (songSecs > 9) Then
            songDurStr = songDurStr & "0"
        End If
        songDurStr = songDurStr & songSecs
        Return songDurStr
    End Function

    'Test-06. Generate a random number (between 120 to 900) for the duration - GetData.pseudoData()
    <Test> _
    Public Sub Generate_Random_Number()
        'Arrange
        Dim firstNumber As Integer = GetData.pseudoData()
        Dim secondNumber As Integer = GetData.pseudoData()
        ' �
        'Act
        Dim NumbersAreNotEqual As Boolean = firstNumber <> secondNumber
        '�
        ' Assert
        Assert.That(firstNumber <> secondNumber, "The numbers should not be equal.")
    End Sub
    Public Shared Property rand As New Random
    Public Shared Function pseudoData()
        'Limit random songTime to 120-900 secs (2-15 mins)
        Dim lower As Integer = 120
        Dim upper As Integer = 900
        Dim songTime As Integer = rand.Next(lower, upper)
        'Assert.ByVal(GetSetting("COM350-08427-01", frmMP3Player.nudSongGaps.Minimum), "The songTime should be an Integer.")
        Return songTime
    End Function

    'Test-07. Convert number into minute and seconds format - GetData.convertDurationString("12:03")
    <Test> _
    Public Sub Does_Integer_Of_Time_Span_Match_Formatted_String()
        Dim durationInteger As Integer = GetData.convertDurationString("12:03")
        Assert.IsTrue(durationInteger = 723, _
            "The song duration of 12:03 should equate to 723 seconds.")
    End Sub
    Public Shared Function convertDurationString(songDurStr As String)
        Dim asciiValue As Integer = 0
        Dim mins2_0to5 As Char = songDurStr.Substring(0, 1)
        Dim mins1_0to9 As Char = songDurStr.Substring(1, 1)
        Dim secs2_0to5 As Char = songDurStr.Substring(3, 1)
        Dim secs1_0to9 As Char = songDurStr.Substring(4, 1)
        Dim timeMins As Integer = 0
        Dim timeMins1 As Integer = 0
        Dim timeMins2 As Integer = 0
        Dim timeSecs As Integer = 0
        Dim timeSecs1 As Integer = 0
        Dim timeSecs2 As Integer = 0
        Dim timeDuration As Integer = 0
        Dim convertsGood As Boolean = False

        'Convert ?m of mm:ss into minutes
        asciiValue = Asc(mins2_0to5)
        'If between 0 to 5
        If (asciiValue >= 48) And (asciiValue <= 53) Then
            timeMins2 = Int32.Parse(mins2_0to5) * 10
        End If

        'Convert m? of mm:ss into minutes
        asciiValue = Asc(mins1_0to9)
        'If between 0 to 9
        If (asciiValue >= 48) And (asciiValue <= 57) Then
            timeMins1 = Int32.Parse(mins1_0to9)
        End If
        timeMins = timeMins2 + timeMins1

        'Convert ?s of mm:ss into seconds
        asciiValue = Asc(secs2_0to5)
        'If between 0 to 5
        If (asciiValue >= 48) And (asciiValue <= 53) Then
            timeSecs2 = Int32.Parse(secs2_0to5) * 10
        End If

        'Convert s? of mm:ss into seconds
        asciiValue = Asc(secs1_0to9)
        'If between 0 to 9
        If (asciiValue >= 48) And (asciiValue <= 57) Then
            timeSecs1 = Int32.Parse(secs1_0to9)
        End If
        timeSecs = timeSecs2 + timeSecs1

        'Tally the time duration mm:ss into seconds
        timeDuration = (timeMins * 60) + timeSecs
        Return timeDuration

    End Function

    'Test-08. Aggregate the song times for the playlist length - frmAssignment1.btnAddSong_Click()
    '         Test Passed - Demonstrated

    'Test-09. If we clear the playlist it must reset the counter back to zero - frmAssignment1.btnDropSong_Click()
    '         Test Passed - Demonstrated
    'Test-10. The gap number is equal to the song count � 1 (frmAssignment1.btnAddSong_Click())
    '         Test Passed - Demonstrated

    'Test-11. Buttons are active as needed - frmAssignment1.lbxSonglist_SelectedIndexChanged()
    '         Test Passed - Demonstrated

    'Test-12. Empty the playList when finished
    '         Test Passed - Demonstrated

    Private Sub DisplayTestResults()
        Dim tests As String = "  UNIT TESTS" & vbLf
        tests &= "  By Michael Fetick" & vbLf
        tests &= "  1. Ensure the directory is valid (GetData::DatafileUtility.DoesDirectoryExists)" & vbLf
        tests &= "     Test Passed - Directory_Does_Exists" & vbLf
        tests &= "     Test Passed - Directory_Does_Not_Exists" & vbLf
        tests &= "  2. A directory must have files (music files) (GetData::DatafileUtility.DoesFileExists)" & vbLf
        tests &= "     Test Passed - File_Does_Exists" & vbLf
        tests &= "     Test Passed - File_Does_Not_Exists" & vbLf
        tests &= "  3. Gap duration must be greater than zero (numericUpDown control nudSongGaps.Minimum = 1)" & vbLf
        tests &= "     Test Passed - Is_Song_Gap_Greater_Than_Zero" & vbLf
        tests &= "  4. My playlist must be at least 20:00 (numericUpDown control nudPlaylistLimit.Minimtestsum = 20)" & vbLf
        tests &= "     Test Passed - Is_PlayList_Duration_At_Least_Twenty_Minutes" & vbLf
        tests &= "  5. Every song must have min/secs - GetData.convertDuration()" & vbLf
        tests &= "     Test Passed - Does_Formatted_String_Match_Integer_Of_Time_Span" & vbLf
        tests &= "  6. Generate a random number (between 120 to 900) for the duration - GetData.pseudoData()" & vbLf
        tests &= "     Test Passed - Generate_Random_Number" & vbLf
        tests &= "  7. Convert string of minute and seconds format into integer of time span - GetData.convertDurationString()" & vbLf
        tests &= "     Test Passed - Does_Integer_Of_Time_Span_Match_Formatted_String" & vbLf
        tests &= "  8. Aggregate the song times for the playlist length - frmAssignment1.btnAddSong_Click()" & vbLf
        tests &= "     Test Passed - Demonstrated" & vbLf
        tests &= "  9. If we clear the playlist it must reset the counter back to zero - frmAssignment1.btnDropSong_Click()" & vbLf
        tests &= "     Test Passed - Demonstrated" & vbLf
        tests &= "10. The gap number is equal to the song count � 1 (frmAssignment1.btnAddSong_Click())" & vbLf
        tests &= "     Test Passed - Demonstrated" & vbLf
        tests &= "11. Buttons are active as needed - frmAssignment1.lbxSonglist_SelectedIndexChanged()" & vbLf
        tests &= "     Test Passed - Demonstrated" & vbLf
        tests &= "12. Empty the playList when finished - frmAssignment1_Load()" & vbLf
        tests &= "     Test Passed - Demonstrated" & vbLf
        MessageBox.Show(tests, "COM350 EXERCISE 1")
    End Sub
End Class
