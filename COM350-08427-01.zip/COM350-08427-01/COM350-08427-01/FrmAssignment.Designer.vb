﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmAssignment
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OptionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pnlMP3player As System.Windows.Forms.Panel
    Friend WithEvents OptionsToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DefaultToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

    Private Sub DefaultToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DefaultToolStripMenuItem.Click
        Dim optionsForm As New frmOptions
        optionsForm.ShowDialog()
    End Sub
    Friend WithEvents lbxPlaylist As System.Windows.Forms.ListBox
    Friend WithEvents lbxSonglist As System.Windows.Forms.ListBox

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.pnlMP3player = New System.Windows.Forms.Panel()
        Me.lblTestResults = New System.Windows.Forms.Label()
        Me.lblAvailableDuration = New System.Windows.Forms.Label()
        Me.lblTimeElapsed = New System.Windows.Forms.Label()
        Me.btnDropSongs = New System.Windows.Forms.Button()
        Me.btnAddSong = New System.Windows.Forms.Button()
        Me.btnDropSong = New System.Windows.Forms.Button()
        Me.btnAddSongs = New System.Windows.Forms.Button()
        Me.lbxPlaylist = New System.Windows.Forms.ListBox()
        Me.lbxSonglist = New System.Windows.Forms.ListBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.OptionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OptionsToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DefaultToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.pnlMP3player.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(38, 60)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1400, 740)
        Me.TabControl1.TabIndex = 10
        Me.TabControl1.TabStop = False
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.pnlMP3player)
        Me.TabPage1.Location = New System.Drawing.Point(4, 34)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1392, 702)
        Me.TabPage1.TabIndex = 11
        Me.TabPage1.Text = "MP3 Player"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'pnlMP3player
        '
        Me.pnlMP3player.Controls.Add(Me.lblTestResults)
        Me.pnlMP3player.Controls.Add(Me.lblAvailableDuration)
        Me.pnlMP3player.Controls.Add(Me.lblTimeElapsed)
        Me.pnlMP3player.Controls.Add(Me.btnDropSongs)
        Me.pnlMP3player.Controls.Add(Me.btnAddSong)
        Me.pnlMP3player.Controls.Add(Me.btnDropSong)
        Me.pnlMP3player.Controls.Add(Me.btnAddSongs)
        Me.pnlMP3player.Controls.Add(Me.lbxPlaylist)
        Me.pnlMP3player.Controls.Add(Me.lbxSonglist)
        Me.pnlMP3player.Location = New System.Drawing.Point(5, 6)
        Me.pnlMP3player.Name = "pnlMP3player"
        Me.pnlMP3player.Size = New System.Drawing.Size(1375, 684)
        Me.pnlMP3player.TabIndex = 13
        '
        'lblTestResults
        '
        Me.lblTestResults.AutoSize = True
        Me.lblTestResults.Enabled = False
        Me.lblTestResults.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTestResults.Location = New System.Drawing.Point(604, 569)
        Me.lblTestResults.Name = "lblTestResults"
        Me.lblTestResults.Size = New System.Drawing.Size(167, 31)
        Me.lblTestResults.TabIndex = 8
        Me.lblTestResults.Text = "Test Results"
        Me.lblTestResults.Visible = False
        '
        'lblAvailableDuration
        '
        Me.lblAvailableDuration.AutoSize = True
        Me.lblAvailableDuration.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAvailableDuration.Location = New System.Drawing.Point(988, 53)
        Me.lblAvailableDuration.Name = "lblAvailableDuration"
        Me.lblAvailableDuration.Size = New System.Drawing.Size(168, 31)
        Me.lblAvailableDuration.TabIndex = 7
        Me.lblAvailableDuration.Text = "(mins : secs)"
        '
        'lblTimeElapsed
        '
        Me.lblTimeElapsed.AutoSize = True
        Me.lblTimeElapsed.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTimeElapsed.Location = New System.Drawing.Point(795, 53)
        Me.lblTimeElapsed.Name = "lblTimeElapsed"
        Me.lblTimeElapsed.Size = New System.Drawing.Size(187, 31)
        Me.lblTimeElapsed.TabIndex = 6
        Me.lblTimeElapsed.Text = "Time Elapsed:"
        '
        'btnDropSongs
        '
        Me.btnDropSongs.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDropSongs.Location = New System.Drawing.Point(610, 420)
        Me.btnDropSongs.Name = "btnDropSongs"
        Me.btnDropSongs.Size = New System.Drawing.Size(150, 50)
        Me.btnDropSongs.TabIndex = 5
        Me.btnDropSongs.Text = "<<"
        Me.btnDropSongs.UseVisualStyleBackColor = True
        '
        'btnAddSong
        '
        Me.btnAddSong.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddSong.Location = New System.Drawing.Point(610, 292)
        Me.btnAddSong.Name = "btnAddSong"
        Me.btnAddSong.Size = New System.Drawing.Size(150, 50)
        Me.btnAddSong.TabIndex = 1
        Me.btnAddSong.Text = ">"
        Me.btnAddSong.UseVisualStyleBackColor = True
        '
        'btnDropSong
        '
        Me.btnDropSong.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDropSong.Location = New System.Drawing.Point(610, 356)
        Me.btnDropSong.Name = "btnDropSong"
        Me.btnDropSong.Size = New System.Drawing.Size(150, 50)
        Me.btnDropSong.TabIndex = 3
        Me.btnDropSong.Text = "<"
        Me.btnDropSong.UseVisualStyleBackColor = True
        '
        'btnAddSongs
        '
        Me.btnAddSongs.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddSongs.Location = New System.Drawing.Point(610, 228)
        Me.btnAddSongs.Name = "btnAddSongs"
        Me.btnAddSongs.Size = New System.Drawing.Size(150, 50)
        Me.btnAddSongs.TabIndex = 4
        Me.btnAddSongs.Text = ">>"
        Me.btnAddSongs.UseVisualStyleBackColor = True
        '
        'lbxPlaylist
        '
        Me.lbxPlaylist.FormattingEnabled = True
        Me.lbxPlaylist.ItemHeight = 25
        Me.lbxPlaylist.Location = New System.Drawing.Point(795, 100)
        Me.lbxPlaylist.Name = "lbxPlaylist"
        Me.lbxPlaylist.Size = New System.Drawing.Size(545, 479)
        Me.lbxPlaylist.TabIndex = 2
        '
        'lbxSonglist
        '
        Me.lbxSonglist.FormattingEnabled = True
        Me.lbxSonglist.ItemHeight = 25
        Me.lbxSonglist.Location = New System.Drawing.Point(30, 100)
        Me.lbxSonglist.Name = "lbxSonglist"
        Me.lbxSonglist.Size = New System.Drawing.Size(545, 479)
        Me.lbxSonglist.TabIndex = 0
        '
        'TabPage2
        '
        Me.TabPage2.Location = New System.Drawing.Point(4, 34)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1392, 702)
        Me.TabPage2.TabIndex = 12
        Me.TabPage2.Text = "Word Searcher"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OptionsToolStripMenuItem, Me.OptionsToolStripMenuItem1})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1474, 45)
        Me.MenuStrip1.TabIndex = 9
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'OptionsToolStripMenuItem
        '
        Me.OptionsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem})
        Me.OptionsToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OptionsToolStripMenuItem.Name = "OptionsToolStripMenuItem"
        Me.OptionsToolStripMenuItem.Size = New System.Drawing.Size(70, 41)
        Me.OptionsToolStripMenuItem.Text = "&File"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(136, 42)
        Me.ExitToolStripMenuItem.Text = "E&xit"
        '
        'OptionsToolStripMenuItem1
        '
        Me.OptionsToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DefaultToolStripMenuItem})
        Me.OptionsToolStripMenuItem1.Font = New System.Drawing.Font("Segoe UI", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OptionsToolStripMenuItem1.Name = "OptionsToolStripMenuItem1"
        Me.OptionsToolStripMenuItem1.Size = New System.Drawing.Size(123, 41)
        Me.OptionsToolStripMenuItem1.Text = "&Options"
        '
        'DefaultToolStripMenuItem
        '
        Me.DefaultToolStripMenuItem.Name = "DefaultToolStripMenuItem"
        Me.DefaultToolStripMenuItem.Size = New System.Drawing.Size(180, 42)
        Me.DefaultToolStripMenuItem.Text = "&Default"
        '
        'FrmAssignment
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1474, 829)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "FrmAssignment"
        Me.Text = "Assignment 1"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.pnlMP3player.ResumeLayout(False)
        Me.pnlMP3player.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
